export interface SukuKataItem {
  id: string;
  word: string; // e.g. "kicap"
  suku1: string; // e.g. "ki" (KV)
  suku2: string; // e.g. "cap" (KVK)
  pola: string; // "KVKVK"
  makna: string; // Penjelasan ringkas mesra murid
  sebutanHuruf: string[]; // ['k-i ki', 'c-a-p cap', 'kicap']
  contohAyat: string;
  nomborLembaran: number; // 1 to 16 mengikut gambar lembaran kerja
  warnaSuku1?: string; // Standard pemulihan: biru
  warnaSuku2?: string; // Standard pemulihan: merah
}

export type GameTab = 'pointer' | 'maze' | 'mario' | 'match' | 'rekod' | 'lembaran';

export interface StudentProfile {
  id: string;
  nama: string;
  kelas: string;
  avatar: string;
  tarikhDaftar: string;
  bintangTerkumpul: number;
  syilingMario: number;
  perkataanDikuasai: string[]; // senarai perkataan id yang telah dikuasai
  perkataanBimbingan: string[]; // perkataan yang memerlukan latihan lanjut
  tahapPenguasaan: number; // 1 hingga 6 (TP1 - TP6)
  rekodAktiviti: ActivityLog[];
}

export interface ActivityLog {
  id: string;
  tarikh: string;
  aktiviti: 'Pointer Perkataan' | 'Maze Runner' | 'Super Mario' | 'Pick and Match' | 'Ujian Ejaan';
  perkataan: string;
  markah: number;
  betul: boolean;
  masaSaat: number;
}

export type PointerType = 'finger' | 'wand' | 'laser';
