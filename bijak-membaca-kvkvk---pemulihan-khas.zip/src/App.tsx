/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { GameTab, StudentProfile } from './types';
import { loadStudents, getActiveStudentId, setActiveStudentId, saveStudents } from './utils/studentStore';
import { soundFx } from './utils/audio';
import { Navbar } from './components/Navbar';
import { OfflineIndicator } from './components/OfflineIndicator';
import { WordPointerModule } from './components/WordPointerModule';
import { MazeRunnerModule } from './components/MazeRunnerModule';
import { SuperMarioModule } from './components/SuperMarioModule';
import { PickAndMatchModule } from './components/PickAndMatchModule';
import { WorksheetModule } from './components/WorksheetModule';
import { StudentReportModal } from './components/StudentReportModal';
import { Sparkles, Heart, Award, Star, BookOpen } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<GameTab>('pointer');
  const [students, setStudents] = useState<StudentProfile[]>([]);
  const [activeStudent, setActiveStudent] = useState<StudentProfile | null>(null);
  const [isReportOpen, setIsReportOpen] = useState(false);
  const [isMuted, setIsMuted] = useState(false);

  // Initialize students
  const refreshStudents = () => {
    const loaded = loadStudents();
    setStudents(loaded);
    const activeId = getActiveStudentId();
    const current = loaded.find((s) => s.id === activeId) || loaded[0];
    setActiveStudent(current);
  };

  useEffect(() => {
    refreshStudents();
  }, []);

  const handleSelectStudent = (student: StudentProfile) => {
    setActiveStudent(student);
    setActiveStudentId(student.id);
  };

  const handleUpdateStudent = (updated: StudentProfile) => {
    setActiveStudent(updated);
    const updatedList = students.map((s) => (s.id === updated.id ? updated : s));
    setStudents(updatedList);
    saveStudents(updatedList);
  };

  const handleToggleMute = () => {
    soundFx.isMuted = !isMuted;
    setIsMuted(!isMuted);
  };

  if (!activeStudent) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-indigo-50">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-indigo-50/60 via-slate-50 to-indigo-50/40 flex flex-col font-remedial">
      {/* Header */}
      <Navbar
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        activeStudent={activeStudent}
        onOpenReport={() => setIsReportOpen(true)}
        isMuted={isMuted}
        onToggleMute={handleToggleMute}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-3 sm:p-6 space-y-6">
        {/* Remedial Teacher Motivational Banner */}
        <section className="bg-gradient-to-r from-indigo-600 via-indigo-700 to-violet-800 rounded-3xl p-5 md:p-6 text-white shadow-lg relative overflow-hidden no-print">
          <div className="absolute -right-8 -bottom-8 w-44 h-44 rounded-full bg-white/10 blur-xl pointer-events-none" />
          <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
            <div className="space-y-1">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/20 backdrop-blur-xs text-xs font-black uppercase text-amber-300">
                <Sparkles className="w-3.5 h-3.5" />
                <span>Pendidikan Pemulihan Khas Interaktif</span>
              </div>
              <h2 className="text-xl md:text-2xl font-black">
                Selamat Datang, Cikgu & {activeStudent.nama.split(' ')[0]}! 👋
              </h2>
              <p className="text-xs md:text-sm text-indigo-100 max-w-2xl">
                Kuasai kemahiran membaca dan mengeja perkataan berasaskan gambar lembaran <strong>KVKVK</strong> melalui 4 aktiviti gamifikasi interaktif.
              </p>
            </div>

            {/* Quick Stats Pill */}
            <div className="flex items-center gap-2 bg-white/10 backdrop-blur-md p-2 rounded-2xl border border-white/20 shrink-0">
              <div className="px-3 py-1.5 rounded-xl bg-white/20 text-center">
                <div className="text-[10px] font-bold uppercase text-indigo-200">Tahap</div>
                <div className="text-sm font-black text-white">TP {activeStudent.tahapPenguasaan}</div>
              </div>
              <div className="px-3 py-1.5 rounded-xl bg-amber-400/30 text-center">
                <div className="text-[10px] font-bold uppercase text-amber-200">Dikuasai</div>
                <div className="text-sm font-black text-amber-300">
                  {activeStudent.perkataanDikuasai.length} / 16
                </div>
              </div>
              <button
                onClick={() => setIsReportOpen(true)}
                className="px-3 py-2 rounded-xl bg-amber-400 hover:bg-amber-300 text-amber-950 font-black text-xs shadow-md transition active:scale-95 cursor-pointer"
              >
                Lihat Rekod ➔
              </button>
            </div>
          </div>
        </section>

        {/* Dynamic Activity Module View */}
        {activeTab === 'pointer' && (
          <WordPointerModule
            activeStudent={activeStudent}
            onUpdateStudent={handleUpdateStudent}
          />
        )}

        {activeTab === 'maze' && (
          <MazeRunnerModule
            activeStudent={activeStudent}
            onUpdateStudent={handleUpdateStudent}
          />
        )}

        {activeTab === 'mario' && (
          <SuperMarioModule
            activeStudent={activeStudent}
            onUpdateStudent={handleUpdateStudent}
          />
        )}

        {activeTab === 'match' && (
          <PickAndMatchModule
            activeStudent={activeStudent}
            onUpdateStudent={handleUpdateStudent}
          />
        )}

        {activeTab === 'lembaran' && (
          <WorksheetModule
            activeStudent={activeStudent}
            onUpdateStudent={handleUpdateStudent}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="mt-auto py-6 text-center text-xs text-slate-500 border-t border-indigo-100/60 bg-white/60 no-print">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-1.5 font-bold text-slate-600">
            <span>Aplikasi Pemulihan Khas KSSR</span>
            <span>•</span>
            <span>Kementerian Pendidikan Malaysia</span>
          </div>
          <div className="text-slate-400 flex items-center gap-1">
            <span>Dibina untuk kemenjadian murid pemulihan khas</span>
            <Heart className="w-3.5 h-3.5 text-rose-500 fill-rose-500" />
          </div>
        </div>
      </footer>

      {/* Offline Connectivity Indicator */}
      <OfflineIndicator />

      {/* Student Progress Record Modal */}
      {isReportOpen && (
        <StudentReportModal
          activeStudent={activeStudent}
          students={students}
          onSelectStudent={handleSelectStudent}
          onRefreshStudents={refreshStudents}
          onClose={() => setIsReportOpen(false)}
        />
      )}
    </div>
  );
}
