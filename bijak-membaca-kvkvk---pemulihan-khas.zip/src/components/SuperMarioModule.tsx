import React, { useState, useEffect, useCallback, useRef } from 'react';
import { SukuKataItem, StudentProfile } from '../types';
import { LEMBARAN_WORDS } from '../data/wordsData';
import { WordImage } from './WordImage';
import { soundFx, sebutSukuKata } from '../utils/audio';
import { rekodKemajuanMurid } from '../utils/studentStore';
import confetti from 'canvas-confetti';
import {
  Gamepad2,
  Volume2,
  ArrowLeft,
  ArrowRight,
  ArrowUp,
  RotateCcw,
  Trophy,
  Coins,
  Sparkles,
  Flag
} from 'lucide-react';

interface Props {
  activeStudent: StudentProfile;
  onUpdateStudent: (updated: StudentProfile) => void;
}

interface BlockItem {
  id: number;
  x: number; // percentage from left: 20%, 45%, 70%
  suku: string;
  isHit: boolean;
  isCorrect: boolean;
  bouncing: boolean;
}

export const SuperMarioModule: React.FC<Props> = ({ activeStudent, onUpdateStudent }) => {
  const [wordIndex, setWordIndex] = useState(0);
  const targetWord = LEMBARAN_WORDS[wordIndex];

  // Mario State
  const [marioX, setMarioX] = useState(15); // Percentage across width (0 to 90)
  const [marioY, setMarioY] = useState(0); // Jump height in pixels
  const [isJumping, setIsJumping] = useState(false);
  const [facing, setFacing] = useState<'left' | 'right'>('right');

  // Gameplay State
  const [stageWordSlot1, setStageWordSlot1] = useState(false);
  const [stageWordSlot2, setStageWordSlot2] = useState(false);
  const [stageFinished, setStageFinished] = useState(false);
  const [stageCoins, setStageCoins] = useState(0);
  const [flagReached, setFlagReached] = useState(false);

  // Blocks setup
  const [blocks, setBlocks] = useState<BlockItem[]>([]);

  // Setup level blocks
  const initStage = useCallback((index: number) => {
    setWordIndex(index);
    setMarioX(15);
    setMarioY(0);
    setIsJumping(false);
    setFacing('right');
    setStageWordSlot1(false);
    setStageWordSlot2(false);
    setStageFinished(false);
    setFlagReached(false);
    setStageCoins(0);

    const curWord = LEMBARAN_WORDS[index];
    // Pick 1 distractor syllable from another word
    const otherWords = LEMBARAN_WORDS.filter((w) => w.id !== curWord.id);
    const randomDistractor = otherWords[Math.floor(Math.random() * otherWords.length)].suku1;

    // 3 blocks: [suku1, distractor, suku2] shuffled
    const items = [
      { suku: curWord.suku1, isCorrect: true, order: 1 },
      { suku: curWord.suku2, isCorrect: true, order: 2 },
      { suku: randomDistractor, isCorrect: false, order: 0 },
    ].sort(() => 0.5 - Math.random());

    const generatedBlocks: BlockItem[] = items.map((item, i) => ({
      id: i,
      x: 25 + i * 26, // 25%, 51%, 77%
      suku: item.suku,
      isHit: false,
      isCorrect: item.isCorrect,
      bouncing: false,
    }));

    setBlocks(generatedBlocks);
    sebutSukuKata(`Kembara Mario: Cari blok tanda soal untuk melengkapkan perkataan ${curWord.word}!`);
  }, []);

  useEffect(() => {
    initStage(wordIndex);
  }, [initStage]);

  // Jump logic
  const handleJump = useCallback(() => {
    if (isJumping || flagReached) return;
    setIsJumping(true);
    soundFx.playJumpSound();

    let height = 0;
    const peak = 130;
    const step = 14;

    // Upward
    const upInterval = setInterval(() => {
      height += step;
      setMarioY(height);

      // Check collision with blocks when near peak
      if (height >= 90) {
        setBlocks((prevBlocks) =>
          prevBlocks.map((block) => {
            const distance = Math.abs(marioX - block.x);
            if (distance < 12 && !block.isHit) {
              // Block Hit!
              soundFx.playCoinSound();
              setStageCoins((c) => c + 1);

              // Check correct sequence
              if (block.suku === targetWord.suku1) {
                setStageWordSlot1(true);
                sebutSukuKata(block.suku);
              } else if (block.suku === targetWord.suku2) {
                setStageWordSlot2(true);
                sebutSukuKata(block.suku);
              } else {
                soundFx.playWrongBuzzer();
                sebutSukuKata(`Bukan '${block.suku}', cuba blok lain ya?`);
              }

              return { ...block, isHit: true, bouncing: true };
            }
            return block;
          })
        );
      }

      if (height >= peak) {
        clearInterval(upInterval);

        // Fall down
        const downInterval = setInterval(() => {
          height -= step;
          setMarioY(Math.max(0, height));
          if (height <= 0) {
            clearInterval(downInterval);
            setIsJumping(false);

            // Reset block bounce
            setBlocks((prev) => prev.map((b) => ({ ...b, bouncing: false })));
          }
        }, 22);
      }
    }, 22);
  }, [isJumping, flagReached, marioX, targetWord]);

  // Check if both syllables collected
  useEffect(() => {
    if (stageWordSlot1 && stageWordSlot2 && !stageFinished) {
      setStageFinished(true);
      soundFx.playSuccessFanfare();
      sebutSukuKata(`Syabas! Suku kata lengkap: ${targetWord.word}! Sekarang lompat ke tiang bendera!`);
    }
  }, [stageWordSlot1, stageWordSlot2, stageFinished, targetWord]);

  // Move Mario horizontally
  const handleMove = useCallback(
    (direction: 'left' | 'right') => {
      if (flagReached) return;

      setFacing(direction);
      setMarioX((prev) => {
        const nextX = direction === 'left' ? Math.max(5, prev - 5) : Math.min(88, prev + 5);

        // If stage is finished and Mario reaches the right side (Flagpole at 82%)
        if (stageFinished && nextX >= 80 && !flagReached) {
          setFlagReached(true);
          soundFx.playSuccessFanfare();
          confetti({ particleCount: 70, spread: 80, origin: { y: 0.5 } });
          sebutSukuKata(`Hebatnya! Awak berjaya melepasi tahap ${targetWord.word}!`);

          const updated = rekodKemajuanMurid(
            activeStudent.id,
            'Super Mario',
            targetWord.id,
            true,
            100,
            15
          );
          onUpdateStudent(updated);
        }

        return nextX;
      });
    },
    [flagReached, stageFinished, targetWord, activeStudent.id, onUpdateStudent]
  );

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'Space' || e.code === 'ArrowUp' || e.code === 'KeyW') {
        e.preventDefault();
        handleJump();
      } else if (e.code === 'ArrowLeft' || e.code === 'KeyA') {
        e.preventDefault();
        handleMove('left');
      } else if (e.code === 'ArrowRight' || e.code === 'KeyD') {
        e.preventDefault();
        handleMove('right');
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleJump, handleMove]);

  const nextStage = () => {
    const nextIdx = (wordIndex + 1) % LEMBARAN_WORDS.length;
    initStage(nextIdx);
  };

  return (
    <div className="rounded-3xl bg-white shadow-xl border-4 border-indigo-100 p-4 md:p-6 select-none">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-slate-100">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-3 py-1 rounded-full bg-rose-100 text-rose-800 text-xs font-bold uppercase tracking-wide">
              Aktiviti 3
            </span>
            <h2 className="text-xl md:text-2xl font-black text-slate-800 flex items-center gap-2">
              <span>Super Mario KVKVK</span>
              <Gamepad2 className="w-5 h-5 text-rose-500" />
            </h2>
          </div>
          <p className="text-xs md:text-sm text-slate-500 mt-0.5">
            Lari dan lompat ketuk blok <strong>[ ? ]</strong> untuk mendedahkan suku kata yang betul!
          </p>
        </div>

        {/* Mario Coins Counter & Reset */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-2xl bg-amber-100 border border-amber-300 text-amber-900 font-black text-sm shadow-xs">
            <Coins className="w-4 h-4 text-amber-600 animate-bounce" />
            <span>Syiling: {activeStudent.syilingMario + stageCoins}</span>
          </div>

          <button
            onClick={() => initStage(wordIndex)}
            className="flex items-center gap-1 px-3 py-1.5 rounded-xl border border-slate-200 text-slate-600 text-xs font-bold hover:bg-slate-50 transition cursor-pointer"
            title="Mula semula pusingan ini"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Mula Semula</span>
          </button>
        </div>
      </div>

      {/* Target Word Dashboard */}
      <div className="my-4 p-4 rounded-2xl bg-gradient-to-r from-sky-50 via-rose-50 to-amber-50 border-2 border-sky-200 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="p-2 rounded-2xl bg-white shadow-md border border-sky-100">
            <WordImage wordId={targetWord.id} className="w-16 h-16 object-contain" />
          </div>
          <div>
            <div className="text-xs font-bold text-sky-800 uppercase tracking-wide">
              Misi Perkataan:
            </div>
            <div className="text-2xl font-black text-slate-800 flex items-center gap-2">
              <span>{targetWord.word}</span>
              <button
                onClick={() => sebutSukuKata(`Misi Mario: lengkapkan perkataan ${targetWord.word}`)}
                className="p-1 rounded-lg text-sky-600 hover:bg-sky-100 transition cursor-pointer"
              >
                <Volume2 className="w-4 h-4" />
              </button>
            </div>
            <div className="text-xs text-slate-500">
              Lompat dan ketuk blok untuk mencari <span className="font-bold text-blue-600">[{targetWord.suku1}]</span> dan <span className="font-bold text-rose-600">[{targetWord.suku2}]</span>
            </div>
          </div>
        </div>

        {/* Word Completion Slots */}
        <div className="flex items-center gap-3">
          <div
            className={`px-4 py-2 rounded-2xl font-black text-lg border-2 transition-all flex items-center gap-2 ${
              stageWordSlot1
                ? 'bg-blue-600 text-white border-blue-700 shadow-md scale-105'
                : 'bg-white text-slate-400 border-dashed border-blue-300'
            }`}
          >
            <span>{stageWordSlot1 ? targetWord.suku1 : '?'}</span>
          </div>

          <span className="text-xl font-bold text-slate-400">+</span>

          <div
            className={`px-4 py-2 rounded-2xl font-black text-lg border-2 transition-all flex items-center gap-2 ${
              stageWordSlot2
                ? 'bg-rose-600 text-white border-rose-700 shadow-md scale-105'
                : 'bg-white text-slate-400 border-dashed border-rose-300'
            }`}
          >
            <span>{stageWordSlot2 ? targetWord.suku2 : '?'}</span>
          </div>
        </div>
      </div>

      {/* Retro Platformer Arena */}
      <div className="relative w-full h-80 rounded-3xl overflow-hidden shadow-2xl border-4 border-sky-300 bg-gradient-to-b from-sky-400 via-sky-300 to-sky-200">
        {/* Retro Pixel Clouds & Sun */}
        <div className="absolute top-4 left-10 text-white/80 text-4xl select-none">☁️</div>
        <div className="absolute top-8 right-24 text-white/80 text-3xl select-none">☁️</div>
        <div className="absolute top-3 right-6 w-12 h-12 rounded-full bg-amber-300 shadow-lg shadow-amber-300/60 ring-4 ring-amber-200/50" />

        {/* Green Rolling Hills in background */}
        <div className="absolute bottom-16 -left-10 w-64 h-32 rounded-t-full bg-emerald-500 opacity-60" />
        <div className="absolute bottom-16 right-10 w-72 h-36 rounded-t-full bg-emerald-600 opacity-50" />

        {/* Mystery [ ? ] Blocks suspended in the air */}
        {blocks.map((b) => (
          <div
            key={b.id}
            className={`absolute flex flex-col items-center transition-transform duration-100 ${
              b.bouncing ? '-translate-y-4' : 'translate-y-0'
            }`}
            style={{
              left: `${b.x}%`,
              top: '80px',
              transform: 'translateX(-50%)',
            }}
          >
            {/* The Mystery Block */}
            <div
              className={`w-14 h-14 rounded-xl border-4 flex flex-col items-center justify-center font-black shadow-lg transition-colors ${
                b.isHit
                  ? 'bg-amber-700/80 border-amber-900 text-amber-200 shadow-inner'
                  : 'bg-amber-400 border-amber-600 text-amber-950 animate-pulse ring-2 ring-amber-300'
              }`}
            >
              {b.isHit ? (
                <span className="text-xs uppercase font-extrabold text-amber-100">
                  {b.suku}
                </span>
              ) : (
                <span className="text-2xl font-black">?</span>
              )}
            </div>

            {/* Syllable revealed tag above block */}
            {b.isHit && (
              <span
                className={`mt-1 text-xs font-black px-2 py-0.5 rounded-md text-white shadow-md animate-bounce ${
                  b.suku === targetWord.suku1
                    ? 'bg-blue-600'
                    : b.suku === targetWord.suku2
                    ? 'bg-rose-600'
                    : 'bg-slate-600'
                }`}
              >
                {b.suku}
              </span>
            )}
          </div>
        ))}

        {/* Victory Flagpole (Appears when both syllables collected) */}
        {stageFinished && (
          <div
            className="absolute bottom-16 right-12 flex flex-col items-center animate-fade-in"
            style={{ zIndex: 10 }}
          >
            <div className="w-2.5 h-44 bg-slate-300 border border-slate-500 shadow-sm rounded-t-sm" />
            <div
              className={`absolute top-2 -left-8 px-2.5 py-1 bg-amber-400 border-2 border-amber-600 text-amber-950 font-black text-xs rounded-r-md shadow-md flex items-center gap-1 ${
                flagReached ? 'translate-y-28 transition-transform duration-700' : 'animate-pulse'
              }`}
            >
              <Flag className="w-3.5 h-3.5 text-amber-800" />
              <span>GOL!</span>
            </div>
            <div className="w-12 h-4 bg-emerald-700 rounded-sm" />
          </div>
        )}

        {/* Mario Character */}
        <div
          className="absolute transition-all duration-75 select-none"
          style={{
            left: `${marioX}%`,
            bottom: `${64 + marioY}px`,
            transform: `translateX(-50%) ${facing === 'left' ? 'scaleX(-1)' : 'scaleX(1)'}`,
            zIndex: 20,
          }}
        >
          <div className="relative text-4xl filter drop-shadow-md">
            <span>🏃‍♂️</span>
          </div>
        </div>

        {/* Ground Platform (Bricks and Grass) */}
        <div className="absolute bottom-0 left-0 w-full h-16 bg-gradient-to-b from-amber-800 to-amber-950 border-t-8 border-emerald-500 flex items-center justify-around px-4">
          {Array.from({ length: 14 }).map((_, i) => (
            <div key={i} className="w-5 h-8 bg-amber-700/60 rounded-xs border-r border-amber-900" />
          ))}
        </div>
      </div>

      {/* Controls Bar for Touch and Mobile */}
      <div className="mt-4 flex flex-wrap items-center justify-between gap-4 bg-slate-50 p-4 rounded-2xl border border-slate-200">
        <div className="flex items-center gap-3">
          <button
            onClick={() => handleMove('left')}
            className="px-5 py-3 rounded-2xl bg-white border-2 border-slate-300 shadow-md text-slate-800 font-bold active:scale-90 transition flex items-center gap-1.5 cursor-pointer"
          >
            <ArrowLeft className="w-5 h-5" />
            <span>Kiri</span>
          </button>
          <button
            onClick={() => handleMove('right')}
            className="px-5 py-3 rounded-2xl bg-white border-2 border-slate-300 shadow-md text-slate-800 font-bold active:scale-90 transition flex items-center gap-1.5 cursor-pointer"
          >
            <span>Kanan</span>
            <ArrowRight className="w-5 h-5" />
          </button>
        </div>

        {/* Big Jump Button */}
        <button
          onClick={handleJump}
          disabled={isJumping}
          className="flex-1 md:flex-initial px-8 py-3.5 rounded-2xl bg-gradient-to-r from-rose-500 to-red-600 text-white font-black text-base shadow-lg shadow-rose-500/30 active:scale-95 transition flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
        >
          <ArrowUp className="w-5 h-5 stroke-[3]" />
          <span>LOMPAT! (Jump)</span>
        </button>

        <div className="text-xs text-slate-400 hidden md:block">
          Tekan <strong>Spacebar</strong> untuk lompat, anak panah untuk bergerak
        </div>
      </div>

      {/* Stage Victory Banner */}
      {flagReached && (
        <div className="mt-6 p-6 rounded-3xl bg-gradient-to-r from-rose-500 via-amber-500 to-indigo-600 text-white text-center shadow-xl flex flex-col md:flex-row items-center justify-between gap-4 animate-fade-in">
          <div className="flex items-center gap-4 text-left">
            <div className="p-3 bg-white/20 rounded-2xl backdrop-blur-xs">
              <Trophy className="w-10 h-10 text-amber-300" />
            </div>
            <div>
              <div className="text-xl md:text-2xl font-black">
                Tahap Selesai! Super Mario Berjaya! 🌟
              </div>
              <p className="text-white/90 text-xs md:text-sm">
                Murid berjaya mengeja perkataan <span className="font-extrabold underline">{targetWord.word}</span> dan mengumpul syiling emas!
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => initStage(wordIndex)}
              className="px-4 py-2.5 rounded-xl bg-white/20 hover:bg-white/30 text-white font-bold text-xs backdrop-blur-xs transition cursor-pointer"
            >
              Main Semula
            </button>
            <button
              onClick={nextStage}
              className="px-5 py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-amber-950 font-black text-sm shadow-md transition active:scale-95 cursor-pointer"
            >
              Tahap Seterusnya ➔
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
