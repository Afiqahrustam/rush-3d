import React from 'react';
import { GameTab, StudentProfile } from '../types';
import { soundFx } from '../utils/audio';
import { PWAInstallButton } from './PWAInstallButton';
import {
  Sparkles,
  Compass,
  Gamepad2,
  Layers,
  FileText,
  Award,
  Volume2,
  VolumeX,
  Star,
  Coins,
  GraduationCap
} from 'lucide-react';

interface Props {
  activeTab: GameTab;
  onSelectTab: (tab: GameTab) => void;
  activeStudent: StudentProfile;
  onOpenReport: () => void;
  isMuted: boolean;
  onToggleMute: () => void;
}

export const Navbar: React.FC<Props> = ({
  activeTab,
  onSelectTab,
  activeStudent,
  onOpenReport,
  isMuted,
  onToggleMute,
}) => {
  const tabs = [
    {
      id: 'pointer' as GameTab,
      label: 'Pointer Perkataan',
      shortLabel: 'Pointer',
      icon: Sparkles,
      color: 'text-amber-500',
      activeBg: 'bg-indigo-600 text-white',
    },
    {
      id: 'maze' as GameTab,
      label: 'Maze Runner',
      shortLabel: 'Maze',
      icon: Compass,
      color: 'text-emerald-500',
      activeBg: 'bg-emerald-600 text-white',
    },
    {
      id: 'mario' as GameTab,
      label: 'Super Mario',
      shortLabel: 'Mario',
      icon: Gamepad2,
      color: 'text-rose-500',
      activeBg: 'bg-rose-600 text-white',
    },
    {
      id: 'match' as GameTab,
      label: 'Pick & Match',
      shortLabel: 'Padan',
      icon: Layers,
      color: 'text-violet-500',
      activeBg: 'bg-violet-600 text-white',
    },
    {
      id: 'lembaran' as GameTab,
      label: 'Lembaran Kerja',
      shortLabel: 'Lembaran',
      icon: FileText,
      color: 'text-sky-500',
      activeBg: 'bg-sky-600 text-white',
    },
  ];

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b-2 border-indigo-100 shadow-xs no-print">
      <div className="max-w-7xl mx-auto px-3 sm:px-6">
        {/* Top Header Row */}
        <div className="flex items-center justify-between py-2.5 gap-2 border-b border-slate-100">
          {/* Logo & Title */}
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-indigo-600 to-violet-600 flex items-center justify-center text-white shadow-md shadow-indigo-500/20">
              <GraduationCap className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h1 className="font-black text-base md:text-lg text-slate-800 tracking-tight leading-none">
                  Bijak Membaca KVKVK
                </h1>
                <span className="px-2 py-0.5 rounded-full bg-indigo-100 text-indigo-700 text-[10px] font-black uppercase">
                  Pemulihan Khas
                </span>
              </div>
              <p className="text-[11px] text-slate-500 font-semibold leading-none mt-1">
                Kementerian Pendidikan Malaysia (KPM)
              </p>
            </div>
          </div>

          {/* Right Action Icons: Active Student, Sound, Install PWA */}
          <div className="flex items-center gap-2">
            {/* Active Student Badge / Report Trigger */}
            <button
              onClick={onOpenReport}
              className="flex items-center gap-2 px-3 py-1.5 rounded-2xl bg-gradient-to-r from-indigo-50 to-violet-50 border border-indigo-200 hover:border-indigo-400 text-slate-700 shadow-2xs transition-all cursor-pointer group"
              title="Buka Rekod Perkembangan Murid"
            >
              <span className="text-xl">{activeStudent.avatar}</span>
              <div className="text-left hidden sm:block">
                <div className="text-xs font-black text-slate-800 leading-none group-hover:text-indigo-600 transition">
                  {activeStudent.nama.split(' ')[0]}
                </div>
                <div className="text-[10px] text-indigo-600 font-bold leading-none mt-0.5">
                  {activeStudent.kelas} • TP {activeStudent.tahapPenguasaan}
                </div>
              </div>
              <div className="flex items-center gap-1.5 pl-1.5 border-l border-indigo-200">
                <span className="flex items-center gap-0.5 text-xs font-black text-amber-600">
                  <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-500" />
                  <span>{activeStudent.bintangTerkumpul}</span>
                </span>
                <span className="hidden md:flex items-center gap-0.5 text-xs font-black text-amber-700">
                  <Coins className="w-3.5 h-3.5 text-amber-600" />
                  <span>{activeStudent.syilingMario}</span>
                </span>
              </div>
            </button>

            {/* Rekod Button Icon */}
            <button
              onClick={onOpenReport}
              className="p-2 rounded-xl bg-amber-50 text-amber-700 border border-amber-200 hover:bg-amber-100 transition cursor-pointer"
              title="Rekod Perkembangan Murid"
            >
              <Award className="w-4 h-4 text-amber-600" />
            </button>

            {/* Sound Toggle */}
            <button
              onClick={onToggleMute}
              className={`p-2 rounded-xl border transition cursor-pointer ${
                isMuted
                  ? 'bg-rose-50 border-rose-200 text-rose-600'
                  : 'bg-slate-100 border-slate-200 text-slate-700 hover:bg-slate-200'
              }`}
              title={isMuted ? 'Bunyi dimatikan (Buka bunyi)' : 'Bunyi aktif (Matikan bunyi)'}
            >
              {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
            </button>

            {/* PWA Install Button */}
            <PWAInstallButton />
          </div>
        </div>

        {/* Tab Navigation Row */}
        <nav className="flex items-center gap-1.5 py-2 overflow-x-auto no-scrollbar">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isSelected = activeTab === tab.id;

            return (
              <button
                key={tab.id}
                onClick={() => {
                  soundFx.playPointerChime();
                  onSelectTab(tab.id);
                }}
                className={`shrink-0 flex items-center gap-2 px-3.5 py-2 rounded-2xl text-xs md:text-sm font-black transition-all cursor-pointer ${
                  isSelected
                    ? `${tab.activeBg} shadow-md scale-102`
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100 bg-white border border-slate-200/80'
                }`}
              >
                <Icon className={`w-4 h-4 ${isSelected ? 'text-white' : tab.color}`} />
                <span className="hidden sm:inline">{tab.label}</span>
                <span className="sm:hidden">{tab.shortLabel}</span>
              </button>
            );
          })}
        </nav>
      </div>
    </header>
  );
};
