import React, { useState, useEffect, useCallback } from 'react';
import { SukuKataItem, StudentProfile } from '../types';
import { LEMBARAN_WORDS } from '../data/wordsData';
import { WordImage } from './WordImage';
import { soundFx, sebutSukuKata } from '../utils/audio';
import { rekodKemajuanMurid } from '../utils/studentStore';
import confetti from 'canvas-confetti';
import {
  Layers,
  Sparkles,
  Trophy,
  CheckCircle2,
  RotateCcw,
  Volume2,
  HelpCircle,
  Puzzle
} from 'lucide-react';

interface Props {
  activeStudent: StudentProfile;
  onUpdateStudent: (updated: StudentProfile) => void;
}

export const PickAndMatchModule: React.FC<Props> = ({ activeStudent, onUpdateStudent }) => {
  const [mode, setMode] = useState<'picture-word' | 'syllable-builder'>('picture-word');

  // Mode 1: Picture to Word Matching (4 pairs at a time)
  const [roundWords, setRoundWords] = useState<SukuKataItem[]>([]);
  const [selectedImageId, setSelectedImageId] = useState<string | null>(null);
  const [selectedWordId, setSelectedWordId] = useState<string | null>(null);
  const [matchedIds, setMatchedIds] = useState<string[]>([]);
  const [shuffledWordCards, setShuffledWordCards] = useState<SukuKataItem[]>([]);

  // Mode 2: Syllable Builder
  const [builderTargetIndex, setBuilderTargetIndex] = useState(0);
  const [chosenSuku1, setChosenSuku1] = useState<string | null>(null);
  const [chosenSuku2, setChosenSuku2] = useState<string | null>(null);
  const [sukuOptions1, setSukuOptions1] = useState<string[]>([]);
  const [sukuOptions2, setSukuOptions2] = useState<string[]>([]);

  // Setup round for Picture to Word
  const initPictureWordRound = useCallback(() => {
    setSelectedImageId(null);
    setSelectedWordId(null);
    setMatchedIds([]);

    // Pick 4 random words from the 16 worksheet words
    const shuffled = [...LEMBARAN_WORDS].sort(() => 0.5 - Math.random()).slice(0, 4);
    setRoundWords(shuffled);
    setShuffledWordCards([...shuffled].sort(() => 0.5 - Math.random()));

    sebutSukuKata('Padankan setiap gambar dengan perkataan yang betul ya?');
  }, []);

  // Setup round for Syllable Builder
  const initSyllableBuilder = useCallback((index: number) => {
    setBuilderTargetIndex(index);
    setChosenSuku1(null);
    setChosenSuku2(null);

    const target = LEMBARAN_WORDS[index];
    const otherWords = LEMBARAN_WORDS.filter((w) => w.id !== target.id);

    // 3 options for Suku 1 (including correct one)
    const s1Opts = [
      target.suku1,
      otherWords[0]?.suku1 || 'ma',
      otherWords[1]?.suku1 || 'ko',
    ].sort(() => 0.5 - Math.random());

    // 3 options for Suku 2 (including correct one)
    const s2Opts = [
      target.suku2,
      otherWords[2]?.suku2 || 'tam',
      otherWords[3]?.suku2 || 'lat',
    ].sort(() => 0.5 - Math.random());

    setSukuOptions1(s1Opts);
    setSukuOptions2(s2Opts);

    sebutSukuKata(`Bina perkataan untuk gambar ${target.word}!`);
  }, []);

  useEffect(() => {
    if (mode === 'picture-word') {
      initPictureWordRound();
    } else {
      initSyllableBuilder(builderTargetIndex);
    }
  }, [mode, initPictureWordRound, initSyllableBuilder, builderTargetIndex]);

  // Handle Match in Picture to Word
  const handleSelectImage = (id: string) => {
    if (matchedIds.includes(id)) return;
    soundFx.playPointerChime();
    setSelectedImageId(id);

    const wordItem = LEMBARAN_WORDS.find((w) => w.id === id);
    if (wordItem) {
      sebutSukuKata(wordItem.word);
    }

    if (selectedWordId) {
      checkPair(id, selectedWordId);
    }
  };

  const handleSelectWord = (id: string) => {
    if (matchedIds.includes(id)) return;
    soundFx.playPointerChime();
    setSelectedWordId(id);

    const wordItem = LEMBARAN_WORDS.find((w) => w.id === id);
    if (wordItem) {
      sebutSukuKata(wordItem.word);
    }

    if (selectedImageId) {
      checkPair(selectedImageId, id);
    }
  };

  const checkPair = (imgId: string, wrdId: string) => {
    if (imgId === wrdId) {
      // Correct match!
      soundFx.playCoinSound();
      soundFx.playSuccessFanfare();
      const newMatched = [...matchedIds, imgId];
      setMatchedIds(newMatched);
      setSelectedImageId(null);
      setSelectedWordId(null);

      const wordObj = LEMBARAN_WORDS.find((w) => w.id === imgId);
      if (wordObj) {
        sebutSukuKata(`Syabas! Padanan tepat: ${wordObj.word}!`);
        const updated = rekodKemajuanMurid(
          activeStudent.id,
          'Pick and Match',
          wordObj.id,
          true,
          100,
          10
        );
        onUpdateStudent(updated);
      }

      if (newMatched.length === roundWords.length) {
        confetti({ particleCount: 60, spread: 70, origin: { y: 0.6 } });
      }
    } else {
      // Wrong match
      soundFx.playWrongBuzzer();
      sebutSukuKata('Cuba lagi ya?');
      setTimeout(() => {
        setSelectedImageId(null);
        setSelectedWordId(null);
      }, 700);
    }
  };

  // Handle Syllable Builder Check
  const handlePickSuku1 = (s: string) => {
    soundFx.playPointerChime();
    setChosenSuku1(s);
    sebutSukuKata(s);
  };

  const handlePickSuku2 = (s: string) => {
    soundFx.playPointerChime();
    setChosenSuku2(s);
    sebutSukuKata(s);
  };

  const currentBuilderWord = LEMBARAN_WORDS[builderTargetIndex];

  const handleValidateBuilder = () => {
    if (!chosenSuku1 || !chosenSuku2) return;

    if (chosenSuku1 === currentBuilderWord.suku1 && chosenSuku2 === currentBuilderWord.suku2) {
      soundFx.playCoinSound();
      soundFx.playSuccessFanfare();
      confetti({ particleCount: 50, spread: 60, origin: { y: 0.6 } });
      sebutSukuKata(`Tahniah! Cantuman betul: ${currentBuilderWord.word}!`);

      const updated = rekodKemajuanMurid(
        activeStudent.id,
        'Pick and Match',
        currentBuilderWord.id,
        true,
        100,
        15
      );
      onUpdateStudent(updated);

      setTimeout(() => {
        const nextIdx = (builderTargetIndex + 1) % LEMBARAN_WORDS.length;
        initSyllableBuilder(nextIdx);
      }, 1800);
    } else {
      soundFx.playWrongBuzzer();
      sebutSukuKata(`Belum tepat. Mari cuba cantumkan semula ya?`);
    }
  };

  return (
    <div className="rounded-3xl bg-white shadow-xl border-4 border-indigo-100 p-4 md:p-6 select-none">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-slate-100">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-3 py-1 rounded-full bg-violet-100 text-violet-800 text-xs font-bold uppercase tracking-wide">
              Aktiviti 4
            </span>
            <h2 className="text-xl md:text-2xl font-black text-slate-800 flex items-center gap-2">
              <span>Pick and Match KVKVK</span>
              <Layers className="w-5 h-5 text-violet-500" />
            </h2>
          </div>
          <p className="text-xs md:text-sm text-slate-500 mt-0.5">
            Padankan gambar dengan perkataan atau cantumkan suku kata yang sepadan!
          </p>
        </div>

        {/* Sub-mode selector */}
        <div className="flex items-center gap-1.5 bg-slate-100 p-1.5 rounded-2xl">
          <button
            onClick={() => setMode('picture-word')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
              mode === 'picture-word'
                ? 'bg-white text-violet-700 shadow-sm border border-slate-200'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Padan Gambar & Perkataan
          </button>
          <button
            onClick={() => setMode('syllable-builder')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
              mode === 'syllable-builder'
                ? 'bg-white text-violet-700 shadow-sm border border-slate-200'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Bina Suku Kata
          </button>
        </div>
      </div>

      {mode === 'picture-word' ? (
        /* MODE 1: PICTURE TO WORD MATCH */
        <div className="mt-4">
          <div className="flex items-center justify-between mb-4">
            <div className="text-xs font-bold text-slate-500">
              Ketik 1 Gambar, kemudian ketik Perkataan yang sepadan dengannya:
            </div>
            <button
              onClick={initPictureWordRound}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-slate-200 text-slate-600 text-xs font-bold hover:bg-slate-50 transition cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Pusingan Baru</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Column 1: Image Cards */}
            <div className="space-y-3">
              <div className="text-xs font-black uppercase text-indigo-600 tracking-wider">
                Kad Gambar:
              </div>
              <div className="grid grid-cols-2 gap-3">
                {roundWords.map((item) => {
                  const isMatched = matchedIds.includes(item.id);
                  const isSelected = selectedImageId === item.id;

                  return (
                    <button
                      key={item.id}
                      disabled={isMatched}
                      onClick={() => handleSelectImage(item.id)}
                      className={`relative p-4 rounded-2xl border-3 flex flex-col items-center justify-center transition-all cursor-pointer ${
                        isMatched
                          ? 'bg-emerald-50 border-emerald-400 opacity-60'
                          : isSelected
                          ? 'bg-violet-100 border-violet-600 shadow-lg scale-105 ring-4 ring-violet-200'
                          : 'bg-white border-slate-200 hover:border-violet-300 hover:bg-violet-50/30'
                      }`}
                    >
                      {isMatched && (
                        <div className="absolute top-2 right-2 p-1 rounded-full bg-emerald-500 text-white">
                          <CheckCircle2 className="w-4 h-4" />
                        </div>
                      )}
                      <WordImage wordId={item.id} className="w-20 h-20 object-contain" />
                      <span className="text-xs text-slate-400 font-bold mt-1">
                        Gambar #{item.nomborLembaran}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Column 2: Word Cards (Shuffled) */}
            <div className="space-y-3">
              <div className="text-xs font-black uppercase text-rose-600 tracking-wider">
                Kad Perkataan:
              </div>
              <div className="grid grid-cols-2 gap-3">
                {shuffledWordCards.map((item) => {
                  const isMatched = matchedIds.includes(item.id);
                  const isSelected = selectedWordId === item.id;

                  return (
                    <button
                      key={item.id}
                      disabled={isMatched}
                      onClick={() => handleSelectWord(item.id)}
                      className={`relative p-4 rounded-2xl border-3 flex flex-col items-center justify-center transition-all cursor-pointer ${
                        isMatched
                          ? 'bg-emerald-50 border-emerald-400 opacity-60'
                          : isSelected
                          ? 'bg-rose-100 border-rose-600 shadow-lg scale-105 ring-4 ring-rose-200'
                          : 'bg-white border-slate-200 hover:border-rose-300 hover:bg-rose-50/30'
                      }`}
                    >
                      {isMatched && (
                        <div className="absolute top-2 right-2 p-1 rounded-full bg-emerald-500 text-white">
                          <CheckCircle2 className="w-4 h-4" />
                        </div>
                      )}
                      <div className="text-2xl font-black py-4">
                        <span className="text-blue-600">{item.suku1}</span>
                        <span className="text-rose-600">{item.suku2}</span>
                      </div>
                      <span className="text-xs text-slate-400 font-bold">
                        {item.word}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Round Complete Banner */}
          {matchedIds.length === roundWords.length && roundWords.length > 0 && (
            <div className="mt-6 p-6 rounded-3xl bg-gradient-to-r from-violet-600 to-indigo-600 text-white flex flex-col md:flex-row items-center justify-between gap-4 shadow-xl animate-fade-in">
              <div className="flex items-center gap-4">
                <div className="p-3 rounded-2xl bg-white/20">
                  <Trophy className="w-8 h-8 text-amber-300" />
                </div>
                <div>
                  <div className="text-xl font-black">Tahniah! Semua Padanan Betul! 🎉</div>
                  <p className="text-xs text-violet-100">
                    Murid berjaya memadankan 4 gambar lembaran dengan tepat!
                  </p>
                </div>
              </div>
              <button
                onClick={initPictureWordRound}
                className="px-5 py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-amber-950 font-black text-sm shadow-md transition active:scale-95 cursor-pointer"
              >
                Pusingan Seterusnya ➔
              </button>
            </div>
          )}
        </div>
      ) : (
        /* MODE 2: SYLLABLE BUILDER */
        <div className="mt-4 max-w-2xl mx-auto">
          {/* Target Card */}
          <div className="p-6 rounded-3xl bg-gradient-to-b from-indigo-50/50 to-white border-2 border-indigo-100 text-center flex flex-col items-center">
            <span className="px-3 py-1 rounded-full bg-indigo-100 text-indigo-800 text-xs font-bold mb-2">
              Gambar #{currentBuilderWord.nomborLembaran} dari 16 Lembaran Kerja
            </span>
            <WordImage wordId={currentBuilderWord.id} className="w-32 h-32 object-contain my-2" />
            <div className="text-sm text-slate-500 italic max-w-sm">
              "{currentBuilderWord.contohAyat}"
            </div>

            {/* Assembled Word Display */}
            <div className="my-5 flex items-center gap-3">
              <div
                className={`w-28 py-3 rounded-2xl font-black text-3xl border-3 flex items-center justify-center transition-all ${
                  chosenSuku1
                    ? 'bg-blue-600 text-white border-blue-700 shadow-md scale-105'
                    : 'bg-white text-slate-400 border-dashed border-blue-300'
                }`}
              >
                {chosenSuku1 || '...'}
              </div>

              <span className="text-2xl font-black text-slate-400">+</span>

              <div
                className={`w-28 py-3 rounded-2xl font-black text-3xl border-3 flex items-center justify-center transition-all ${
                  chosenSuku2
                    ? 'bg-rose-600 text-white border-rose-700 shadow-md scale-105'
                    : 'bg-white text-slate-400 border-dashed border-rose-300'
                }`}
              >
                {chosenSuku2 || '...'}
              </div>
            </div>

            {/* Suku 1 Options */}
            <div className="w-full my-2">
              <div className="text-xs font-bold text-blue-700 mb-2">
                Langkah 1: Pilih Suku Kata Awal (Biru):
              </div>
              <div className="flex justify-center gap-3">
                {sukuOptions1.map((s) => (
                  <button
                    key={s}
                    onClick={() => handlePickSuku1(s)}
                    className={`px-5 py-2.5 rounded-xl font-black text-xl border-2 transition-all cursor-pointer ${
                      chosenSuku1 === s
                        ? 'bg-blue-600 text-white border-blue-700 ring-4 ring-blue-200'
                        : 'bg-white text-blue-700 border-blue-200 hover:bg-blue-50'
                    }`}
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>

            {/* Suku 2 Options */}
            <div className="w-full my-3">
              <div className="text-xs font-bold text-rose-700 mb-2">
                Langkah 2: Pilih Suku Kata Akhir (Merah):
              </div>
              <div className="flex justify-center gap-3">
                {sukuOptions2.map((s) => (
                  <button
                    key={s}
                    onClick={() => handlePickSuku2(s)}
                    className={`px-5 py-2.5 rounded-xl font-black text-xl border-2 transition-all cursor-pointer ${
                      chosenSuku2 === s
                        ? 'bg-rose-600 text-white border-rose-700 ring-4 ring-rose-200'
                        : 'bg-white text-rose-700 border-rose-200 hover:bg-rose-50'
                    }`}
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>

            {/* Submit button */}
            <button
              disabled={!chosenSuku1 || !chosenSuku2}
              onClick={handleValidateBuilder}
              className="mt-4 px-8 py-3 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-600 text-white font-black text-base shadow-lg shadow-emerald-500/20 active:scale-95 transition disabled:opacity-40 cursor-pointer"
            >
              Semak Cantuman Suku Kata
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
