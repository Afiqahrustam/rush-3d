import React, { useState, useEffect, useRef } from 'react';
import { SukuKataItem, StudentProfile, PointerType } from '../types';
import { LEMBARAN_WORDS } from '../data/wordsData';
import { WordImage } from './WordImage';
import { soundFx, sebutSukuKata, sebutEjaanPenuh } from '../utils/audio';
import { rekodKemajuanMurid } from '../utils/studentStore';
import confetti from 'canvas-confetti';
import {
  Sparkles,
  Volume2,
  ChevronLeft,
  ChevronRight,
  Hand,
  Wand2,
  Zap,
  HelpCircle,
  CheckCircle2,
  Play,
  RotateCcw,
  Trophy
} from 'lucide-react';

interface Props {
  activeStudent: StudentProfile;
  onUpdateStudent: (updated: StudentProfile) => void;
}

export const WordPointerModule: React.FC<Props> = ({ activeStudent, onUpdateStudent }) => {
  const [selectedWordIndex, setSelectedWordIndex] = useState(0);
  const [pointerType, setPointerType] = useState<PointerType>('finger');
  const [activeSukuHighlight, setActiveSukuHighlight] = useState<1 | 2 | 'full' | null>(null);
  const [isAutoSpelling, setIsAutoSpelling] = useState(false);
  const [speed, setSpeed] = useState<'slow' | 'normal' | 'fast'>('normal');
  const [quizMode, setQuizMode] = useState(false);
  const [quizTarget, setQuizTarget] = useState<SukuKataItem | null>(null);
  const [quizScore, setQuizScore] = useState(0);
  const [quizFeedback, setQuizFeedback] = useState<string | null>(null);

  // Mouse / Pointer position
  const [pointerPos, setPointerPos] = useState({ x: -100, y: -100, visible: false });
  const containerRef = useRef<HTMLDivElement>(null);

  const currentWord = LEMBARAN_WORDS[selectedWordIndex];

  const speedMs = speed === 'slow' ? 1400 : speed === 'normal' ? 900 : 600;

  // Handle pointer tracking
  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    setPointerPos({
      x: e.clientX - rect.left,
      y: e.clientY - rect.top,
      visible: true,
    });
  };

  const handleMouseLeave = () => {
    setPointerPos((prev) => ({ ...prev, visible: false }));
  };

  // Automated Eja Bersama Cikgu
  const handleAutoSpell = async () => {
    if (isAutoSpelling) return;
    setIsAutoSpelling(true);

    soundFx.playPointerChime();
    setActiveSukuHighlight(1);
    sebutSukuKata(`${currentWord.suku1}`);

    setTimeout(() => {
      soundFx.playPointerChime();
      setActiveSukuHighlight(2);
      sebutSukuKata(`${currentWord.suku2}`);

      setTimeout(() => {
        soundFx.playSuccessFanfare();
        setActiveSukuHighlight('full');
        sebutSukuKata(`${currentWord.word}!`);

        // Record progress in student store
        const updated = rekodKemajuanMurid(
          activeStudent.id,
          'Pointer Perkataan',
          currentWord.id,
          true,
          100,
          10
        );
        onUpdateStudent(updated);

        setTimeout(() => {
          setActiveSukuHighlight(null);
          setIsAutoSpelling(false);
        }, speedMs);
      }, speedMs);
    }, speedMs);
  };

  const handleSukuClick = (part: 1 | 2) => {
    soundFx.playPointerChime();
    setActiveSukuHighlight(part);
    if (part === 1) {
      sebutSukuKata(currentWord.suku1);
    } else {
      sebutSukuKata(currentWord.suku2);
    }
    setTimeout(() => setActiveSukuHighlight(null), 1000);
  };

  const handleFullWordClick = () => {
    soundFx.playPointerChime();
    setActiveSukuHighlight('full');
    sebutEjaanPenuh(currentWord.suku1, currentWord.suku2, currentWord.word);
    setTimeout(() => setActiveSukuHighlight(null), 1400);
  };

  // Start Pointer Quiz Mode
  const startQuiz = () => {
    setQuizMode(true);
    setQuizScore(0);
    nextQuizQuestion();
  };

  const nextQuizQuestion = () => {
    setQuizFeedback(null);
    const randomIdx = Math.floor(Math.random() * LEMBARAN_WORDS.length);
    const target = LEMBARAN_WORDS[randomIdx];
    setQuizTarget(target);
    soundFx.playPointerChime();
    sebutSukuKata(`Manakah perkataan... ${target.word}?`);
  };

  const handleQuizAnswer = (wordItem: SukuKataItem) => {
    if (!quizTarget) return;

    if (wordItem.id === quizTarget.id) {
      soundFx.playCoinSound();
      soundFx.playSuccessFanfare();
      confetti({ particleCount: 40, spread: 60, origin: { y: 0.7 } });
      setQuizScore((prev) => prev + 1);
      setQuizFeedback(`Syabas! Ini perkataan ${wordItem.word.toUpperCase()}!`);
      sebutSukuKata(`Syabas! Ini perkataan ${wordItem.word}!`);

      const updated = rekodKemajuanMurid(
        activeStudent.id,
        'Pointer Perkataan',
        wordItem.id,
        true,
        100,
        12
      );
      onUpdateStudent(updated);

      setTimeout(() => {
        nextQuizQuestion();
      }, 1600);
    } else {
      soundFx.playWrongBuzzer();
      setQuizFeedback(`Cuba lagi ya? Ini ialah perkataan ${wordItem.word}.`);
      sebutSukuKata(`Cuba lagi ya? Ini ialah perkataan ${wordItem.word}.`);
    }
  };

  return (
    <div
      ref={containerRef}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      className="relative rounded-3xl bg-white shadow-xl border-4 border-indigo-100 p-4 md:p-6 overflow-hidden select-none"
    >
      {/* Floating Pointer Cursor */}
      {pointerPos.visible && (
        <div
          className="pointer-events-none absolute z-50 transition-transform duration-75 ease-out"
          style={{
            left: `${pointerPos.x}px`,
            top: `${pointerPos.y}px`,
            transform: 'translate(-30%, -30%)',
          }}
        >
          {pointerType === 'finger' && (
            <div className="relative">
              <span className="text-4xl filter drop-shadow-md">👉</span>
              <span className="absolute -top-1 -right-1 flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-indigo-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-indigo-500"></span>
              </span>
            </div>
          )}
          {pointerType === 'wand' && (
            <div className="relative animate-wand-glow">
              <span className="text-4xl">🪄</span>
              <Sparkles className="absolute -top-3 -right-3 w-5 h-5 text-amber-400 animate-spin" />
            </div>
          )}
          {pointerType === 'laser' && (
            <div className="relative">
              <div className="w-5 h-5 rounded-full bg-rose-600 shadow-lg shadow-rose-500/80 ring-4 ring-rose-300 animate-pulse-ring" />
            </div>
          )}
        </div>
      )}

      {/* Header Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-slate-100">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-3 py-1 rounded-full bg-blue-100 text-blue-800 text-xs font-bold uppercase tracking-wide">
              Aktiviti 1
            </span>
            <h2 className="text-xl md:text-2xl font-black text-slate-800 flex items-center gap-2">
              <span>Pointer Perkataan</span>
              <Sparkles className="w-5 h-5 text-amber-500" />
            </h2>
          </div>
          <p className="text-xs md:text-sm text-slate-500 mt-0.5">
            Gunakan penunjuk interaktif untuk mengeja suku kata satu demi satu.
          </p>
        </div>

        {/* Pointer Style Picker */}
        <div className="flex items-center gap-1.5 bg-slate-100 p-1.5 rounded-2xl">
          <span className="text-xs font-bold text-slate-500 px-2">Penunjuk:</span>
          <button
            onClick={() => setPointerType('finger')}
            className={`flex items-center gap-1 px-2.5 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
              pointerType === 'finger'
                ? 'bg-white text-indigo-700 shadow-sm border border-slate-200'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Hand className="w-3.5 h-3.5" />
            <span>Jari</span>
          </button>
          <button
            onClick={() => setPointerType('wand')}
            className={`flex items-center gap-1 px-2.5 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
              pointerType === 'wand'
                ? 'bg-white text-indigo-700 shadow-sm border border-slate-200'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Wand2 className="w-3.5 h-3.5" />
            <span>Sakti</span>
          </button>
          <button
            onClick={() => setPointerType('laser')}
            className={`flex items-center gap-1 px-2.5 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
              pointerType === 'laser'
                ? 'bg-white text-rose-600 shadow-sm border border-slate-200'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Zap className="w-3.5 h-3.5" />
            <span>Laser</span>
          </button>
        </div>
      </div>

      {/* Quiz Toggle or Normal Practice Mode */}
      {!quizMode ? (
        <div className="mt-4">
          {/* Main Card */}
          <div className="bg-gradient-to-b from-indigo-50/60 to-white rounded-3xl border-2 border-indigo-100 p-5 md:p-8 flex flex-col md:flex-row items-center justify-between gap-6">
            {/* Left: Illustration with worksheet index tag */}
            <div className="relative flex flex-col items-center">
              <div className="relative p-6 rounded-3xl bg-white shadow-lg border-2 border-indigo-100/80 group">
                <span className="absolute top-2 left-3 px-2 py-0.5 rounded-md bg-amber-100 text-amber-900 text-xs font-black">
                  #{currentWord.nomborLembaran}
                </span>
                <WordImage wordId={currentWord.id} className="w-36 h-36 md:w-44 md:h-44 object-contain transition-transform group-hover:scale-105" />
                <button
                  onClick={() => sebutSukuKata(`Ini gambar ${currentWord.word}`)}
                  className="absolute bottom-2 right-2 p-2 rounded-full bg-indigo-50 text-indigo-600 hover:bg-indigo-100 transition shadow-xs cursor-pointer"
                  title="Dengar nama gambar"
                >
                  <Volume2 className="w-4 h-4" />
                </button>
              </div>
              <p className="mt-2 text-xs text-slate-500 italic max-w-xs text-center">
                "{currentWord.contohAyat}"
              </p>
            </div>

            {/* Center: Syllable breakdown display with remedial KPM styling */}
            <div className="flex-1 flex flex-col items-center text-center">
              <div className="text-xs font-black uppercase text-indigo-500 tracking-wider mb-2">
                Pola Suku Kata: {currentWord.pola}
              </div>

              {/* Syllable Buttons */}
              <div className="flex items-center gap-3 my-2">
                {/* Suku Kata 1 (KV) - Standard Blue */}
                <button
                  onClick={() => handleSukuClick(1)}
                  className={`group relative px-6 py-4 rounded-2xl text-4xl md:text-5xl font-black border-4 transition-all transform active:scale-95 cursor-pointer ${
                    activeSukuHighlight === 1 || activeSukuHighlight === 'full'
                      ? 'bg-blue-500 text-white border-blue-600 shadow-xl scale-110 ring-4 ring-blue-300'
                      : 'bg-blue-50 text-blue-700 border-blue-200 hover:bg-blue-100 hover:border-blue-400'
                  }`}
                >
                  <span>{currentWord.suku1}</span>
                  <span className="absolute -bottom-2.5 left-1/2 -translate-x-1/2 text-[10px] font-bold px-2 py-0.5 rounded-full bg-blue-700 text-white">
                    suku awal
                  </span>
                </button>

                <span className="text-3xl font-black text-slate-300">+</span>

                {/* Suku Kata 2 (KVK) - Standard Red */}
                <button
                  onClick={() => handleSukuClick(2)}
                  className={`group relative px-6 py-4 rounded-2xl text-4xl md:text-5xl font-black border-4 transition-all transform active:scale-95 cursor-pointer ${
                    activeSukuHighlight === 2 || activeSukuHighlight === 'full'
                      ? 'bg-rose-500 text-white border-rose-600 shadow-xl scale-110 ring-4 ring-rose-300'
                      : 'bg-rose-50 text-rose-700 border-rose-200 hover:bg-rose-100 hover:border-rose-400'
                  }`}
                >
                  <span>{currentWord.suku2}</span>
                  <span className="absolute -bottom-2.5 left-1/2 -translate-x-1/2 text-[10px] font-bold px-2 py-0.5 rounded-full bg-rose-700 text-white">
                    suku akhir
                  </span>
                </button>
              </div>

              {/* Full Word Pronunciation */}
              <button
                onClick={handleFullWordClick}
                className={`mt-4 px-8 py-3 rounded-2xl text-2xl md:text-3xl font-black tracking-wide border-2 transition-all cursor-pointer flex items-center gap-3 ${
                  activeSukuHighlight === 'full'
                    ? 'bg-indigo-600 text-white border-indigo-700 shadow-lg scale-105'
                    : 'bg-white text-slate-800 border-indigo-200 hover:border-indigo-400 hover:bg-indigo-50/50'
                }`}
              >
                <span>
                  <span className="text-blue-600">{currentWord.suku1}</span>
                  <span className="text-rose-600">{currentWord.suku2}</span>
                </span>
                <Volume2 className="w-6 h-6 text-indigo-500" />
              </button>

              {/* Action Buttons */}
              <div className="flex flex-wrap items-center justify-center gap-3 mt-6">
                <button
                  disabled={isAutoSpelling}
                  onClick={handleAutoSpell}
                  className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-indigo-600 to-violet-600 text-white font-bold text-sm shadow-md hover:from-indigo-700 hover:to-violet-700 active:scale-95 transition disabled:opacity-50 cursor-pointer"
                >
                  <Play className="w-4 h-4 fill-white" />
                  <span>{isAutoSpelling ? 'Sedang Mengeja...' : 'Eja Bersama Cikgu'}</span>
                </button>

                <button
                  onClick={startQuiz}
                  className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-amber-500 text-white font-bold text-sm shadow-md hover:bg-amber-600 active:scale-95 transition cursor-pointer"
                >
                  <HelpCircle className="w-4 h-4" />
                  <span>Kuiz Cari Kata</span>
                </button>
              </div>

              {/* Speed Controls */}
              <div className="flex items-center gap-2 mt-4 text-xs text-slate-500">
                <span className="font-bold">Kelajuan:</span>
                {(['slow', 'normal', 'fast'] as const).map((s) => (
                  <button
                    key={s}
                    onClick={() => setSpeed(s)}
                    className={`px-2.5 py-1 rounded-lg font-bold transition cursor-pointer ${
                      speed === s
                        ? 'bg-indigo-100 text-indigo-800 border border-indigo-300'
                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    {s === 'slow' ? 'Perlahan' : s === 'normal' ? 'Sederhana' : 'Laju'}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Navigation Thumbnails */}
          <div className="mt-5 flex items-center justify-between gap-2">
            <button
              onClick={() => setSelectedWordIndex((prev) => (prev > 0 ? prev - 1 : LEMBARAN_WORDS.length - 1))}
              className="p-2.5 rounded-2xl bg-white border-2 border-slate-200 text-slate-700 hover:bg-indigo-50 hover:border-indigo-300 active:scale-95 transition shadow-xs cursor-pointer"
              title="Perkataan sebelum"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>

            {/* Thumbnail Carousel */}
            <div className="flex-1 overflow-x-auto py-2 flex items-center gap-2.5 no-scrollbar">
              {LEMBARAN_WORDS.map((w, idx) => {
                const isDikuasai = activeStudent.perkataanDikuasai.includes(w.id);
                return (
                  <button
                    key={w.id}
                    onClick={() => {
                      setSelectedWordIndex(idx);
                      soundFx.playPointerChime();
                    }}
                    className={`shrink-0 flex items-center gap-2 px-3 py-2 rounded-2xl border-2 transition-all cursor-pointer ${
                      selectedWordIndex === idx
                        ? 'bg-indigo-600 text-white border-indigo-700 shadow-md scale-105'
                        : 'bg-white text-slate-700 border-slate-200 hover:border-indigo-300 hover:bg-indigo-50/50'
                    }`}
                  >
                    <WordImage wordId={w.id} className="w-6 h-6 object-contain" />
                    <span className="font-bold text-xs">{w.word}</span>
                    {isDikuasai && (
                      <span className="w-2 h-2 rounded-full bg-emerald-400" title="Telah Dikuasai" />
                    )}
                  </button>
                );
              })}
            </div>

            <button
              onClick={() => setSelectedWordIndex((prev) => (prev < LEMBARAN_WORDS.length - 1 ? prev + 1 : 0))}
              className="p-2.5 rounded-2xl bg-white border-2 border-slate-200 text-slate-700 hover:bg-indigo-50 hover:border-indigo-300 active:scale-95 transition shadow-xs cursor-pointer"
              title="Perkataan seterusnya"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        </div>
      ) : (
        /* Quiz Mode */
        <div className="mt-4 bg-gradient-to-b from-amber-50 to-white rounded-3xl border-2 border-amber-200 p-5 md:p-8">
          <div className="flex items-center justify-between pb-4 border-b border-amber-200">
            <div className="flex items-center gap-2">
              <Trophy className="w-6 h-6 text-amber-500" />
              <div>
                <h3 className="font-black text-slate-800 text-lg">Kuiz Penunjuk: Cari Kata</h3>
                <p className="text-xs text-slate-600">
                  Dengar soalan, kemudian ketik atau hala penunjuk pada perkataan yang betul!
                </p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="px-3 py-1.5 rounded-xl bg-amber-500 text-white font-black text-sm flex items-center gap-1.5 shadow-sm">
                <span>⭐</span>
                <span>Markah: {quizScore}</span>
              </div>
              <button
                onClick={() => setQuizMode(false)}
                className="px-3 py-1.5 rounded-xl bg-white border border-slate-300 text-xs font-bold text-slate-600 hover:bg-slate-100 transition cursor-pointer"
              >
                Tamat Kuiz
              </button>
            </div>
          </div>

          {/* Question Banner */}
          {quizTarget && (
            <div className="my-6 text-center">
              <div className="inline-flex items-center gap-3 px-6 py-3 rounded-2xl bg-white shadow-md border-2 border-amber-300">
                <button
                  onClick={() => sebutSukuKata(`Manakah perkataan... ${quizTarget.word}?`)}
                  className="p-2 rounded-xl bg-amber-100 text-amber-800 hover:bg-amber-200 transition"
                  title="Ulang soalan"
                >
                  <Volume2 className="w-6 h-6" />
                </button>
                <div className="text-left">
                  <span className="text-xs font-bold text-amber-700 uppercase">Soalan Guru:</span>
                  <div className="text-xl md:text-2xl font-black text-slate-800">
                    Manakah perkataan <span className="underline decoration-amber-500 font-extrabold">"{quizTarget.word}"</span>?
                  </div>
                </div>
              </div>

              {quizFeedback && (
                <div className="mt-3 text-sm font-bold text-indigo-700 animate-bounce">
                  {quizFeedback}
                </div>
              )}
            </div>
          )}

          {/* 6 Choices Grid */}
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4 max-w-2xl mx-auto">
            {LEMBARAN_WORDS.slice(0, 6)
              .sort(() => (quizTarget ? 0.5 - Math.random() : 0))
              .map((w) => (
                <button
                  key={w.id}
                  onClick={() => handleQuizAnswer(w)}
                  className="p-4 rounded-2xl bg-white border-2 border-slate-200 hover:border-amber-400 hover:bg-amber-50/40 hover:shadow-lg transition-all active:scale-95 flex flex-col items-center gap-2 cursor-pointer group"
                >
                  <WordImage wordId={w.id} className="w-20 h-20 object-contain group-hover:scale-105 transition-transform" />
                  <div className="text-xl font-black">
                    <span className="text-blue-600">{w.suku1}</span>
                    <span className="text-rose-600">{w.suku2}</span>
                  </div>
                </button>
              ))}
          </div>
        </div>
      )}
    </div>
  );
};
