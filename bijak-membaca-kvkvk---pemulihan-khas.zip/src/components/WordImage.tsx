import React from 'react';

interface WordImageProps {
  wordId: string;
  className?: string;
}

export const WordImage: React.FC<WordImageProps> = ({ wordId, className = 'w-24 h-24' }) => {
  switch (wordId) {
    case 'kicap':
      return (
        <svg viewBox="0 0 120 120" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          {/* Soy sauce bottle & dipping bowl */}
          <ellipse cx="38" cy="100" rx="22" ry="7" fill="#cbd5e1" opacity="0.6" />
          <ellipse cx="90" cy="104" rx="20" ry="6" fill="#cbd5e1" opacity="0.6" />
          {/* Bottle */}
          <path d="M26 60 C26 42 32 32 34 26 L42 26 C44 32 50 42 50 60 L54 94 C54 98 50 102 44 102 L32 102 C26 102 22 98 22 94 Z" fill="#2d1b16" stroke="#1f2937" strokeWidth="2.5" />
          {/* Sauce level */}
          <path d="M24 72 C24 72 32 74 38 74 C44 74 52 72 52 72 L54 94 C54 98 50 102 44 102 L32 102 C26 102 22 98 22 94 Z" fill="#180e0c" />
          {/* Bottle neck & red cap */}
          <rect x="33" y="16" width="10" height="10" fill="#dc2626" rx="2" stroke="#991b1b" strokeWidth="1.5" />
          <polygon points="38,12 30,16 46,16" fill="#ef4444" stroke="#991b1b" strokeWidth="1.5" />
          {/* Label on bottle */}
          <rect x="28" y="70" width="20" height="18" fill="#fef08a" rx="2" stroke="#ca8a04" strokeWidth="1" />
          <text x="38" y="82" fontSize="7" fontWeight="bold" fill="#713f12" textAnchor="middle" fontFamily="sans-serif">KICAP</text>
          {/* Dipping bowl with sauce */}
          <ellipse cx="90" cy="95" rx="20" ry="9" fill="#f8fafc" stroke="#64748b" strokeWidth="2" />
          <ellipse cx="90" cy="95" rx="16" ry="6.5" fill="#180e0c" />
          <ellipse cx="86" cy="94" rx="4" ry="1.5" fill="#ffffff" opacity="0.4" />
        </svg>
      );

    case 'kotak':
      return (
        <svg viewBox="0 0 120 120" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          {/* Cardboard box 3D open top */}
          <ellipse cx="60" cy="106" rx="40" ry="8" fill="#cbd5e1" opacity="0.5" />
          {/* Front faces */}
          <polygon points="20,55 60,78 60,105 20,82" fill="#d97706" stroke="#78350f" strokeWidth="2.5" />
          <polygon points="60,78 100,55 100,82 60,105" fill="#b45309" stroke="#78350f" strokeWidth="2.5" />
          {/* Inner back */}
          <polygon points="20,55 60,32 100,55 60,78" fill="#92400e" stroke="#78350f" strokeWidth="2.5" />
          {/* Flaps open */}
          <polygon points="20,55 10,40 50,22 60,32" fill="#f59e0b" stroke="#78350f" strokeWidth="2" />
          <polygon points="100,55 110,40 70,22 60,32" fill="#d97706" stroke="#78350f" strokeWidth="2" />
          <polygon points="20,55 35,68 15,75" fill="#fbbf24" stroke="#78350f" strokeWidth="1.5" />
          <polygon points="100,55 85,68 105,75" fill="#d97706" stroke="#78350f" strokeWidth="1.5" />
          {/* Tape line */}
          <line x1="38" y1="65" x2="38" y2="92" stroke="#78350f" strokeWidth="1.5" strokeDasharray="3 2" />
        </svg>
      );

    case 'kurus':
      return (
        <svg viewBox="0 0 120 120" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          {/* Thin smiling boy */}
          <ellipse cx="60" cy="112" rx="24" ry="5" fill="#cbd5e1" opacity="0.5" />
          {/* Head & Hair */}
          <circle cx="60" cy="30" r="18" fill="#fed7aa" stroke="#78350f" strokeWidth="2" />
          <path d="M42 28 C42 16 52 12 60 12 C68 12 78 16 78 28 C74 24 66 22 60 22 C54 22 46 24 42 28 Z" fill="#92400e" />
          {/* Face */}
          <circle cx="53" cy="30" r="2.5" fill="#1f2937" />
          <circle cx="67" cy="30" r="2.5" fill="#1f2937" />
          <path d="M56 36 Q60 40 64 36" stroke="#dc2626" strokeWidth="2" strokeLinecap="round" />
          {/* Thin Neck & Torso */}
          <rect x="57" y="47" width="6" height="8" fill="#fed7aa" />
          <rect x="52" y="55" width="16" height="28" fill="#fed7aa" stroke="#78350f" strokeWidth="2" rx="3" />
          {/* Ribs (showing slim) */}
          <line x1="55" y1="64" x2="65" y2="64" stroke="#f97316" strokeWidth="1.5" opacity="0.7" />
          <line x1="56" y1="70" x2="64" y2="70" stroke="#f97316" strokeWidth="1.5" opacity="0.7" />
          {/* Arms */}
          <line x1="52" y1="58" x2="42" y2="78" stroke="#fed7aa" strokeWidth="5" strokeLinecap="round" />
          <line x1="52" y1="58" x2="42" y2="78" stroke="#78350f" strokeWidth="1.5" strokeLinecap="round" />
          <line x1="68" y1="58" x2="78" y2="78" stroke="#fed7aa" strokeWidth="5" strokeLinecap="round" />
          <line x1="68" y1="58" x2="78" y2="78" stroke="#78350f" strokeWidth="1.5" strokeLinecap="round" />
          {/* Shorts */}
          <path d="M50 82 L70 82 L68 96 L62 96 L60 90 L58 96 L52 96 Z" fill="#3b82f6" stroke="#1d4ed8" strokeWidth="2" />
          {/* Thin legs */}
          <line x1="55" y1="96" x2="55" y2="110" stroke="#78350f" strokeWidth="4" strokeLinecap="round" />
          <line x1="65" y1="96" x2="65" y2="110" stroke="#78350f" strokeWidth="4" strokeLinecap="round" />
        </svg>
      );

    case 'ketam':
      return (
        <svg viewBox="0 0 120 120" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          {/* Cheerful cartoon red crab */}
          <ellipse cx="60" cy="108" rx="36" ry="6" fill="#cbd5e1" opacity="0.5" />
          {/* Claws Left */}
          <path d="M42 56 C26 44 14 36 18 24 C22 12 36 20 40 32" stroke="#dc2626" strokeWidth="7" strokeLinecap="round" />
          <path d="M16 26 C12 20 14 14 22 18 C28 22 26 30 16 26 Z" fill="#ef4444" stroke="#991b1b" strokeWidth="2" />
          <path d="M22 18 C26 10 34 16 30 24" fill="#ef4444" stroke="#991b1b" strokeWidth="2" />
          {/* Claws Right */}
          <path d="M78 56 C94 44 106 36 102 24 C98 12 84 20 80 32" stroke="#dc2626" strokeWidth="7" strokeLinecap="round" />
          <path d="M104 26 C108 20 106 14 98 18 C92 22 94 30 104 26 Z" fill="#ef4444" stroke="#991b1b" strokeWidth="2" />
          <path d="M98 18 C94 10 86 16 90 24" fill="#ef4444" stroke="#991b1b" strokeWidth="2" />
          {/* Legs */}
          <path d="M36 78 C20 82 16 94 24 102" stroke="#dc2626" strokeWidth="4" strokeLinecap="round" />
          <path d="M38 88 C26 94 24 102 32 106" stroke="#dc2626" strokeWidth="4" strokeLinecap="round" />
          <path d="M84 78 C100 82 104 94 96 102" stroke="#dc2626" strokeWidth="4" strokeLinecap="round" />
          <path d="M82 88 C94 94 96 102 88 106" stroke="#dc2626" strokeWidth="4" strokeLinecap="round" />
          {/* Main body shell */}
          <ellipse cx="60" cy="74" rx="32" ry="24" fill="#ef4444" stroke="#991b1b" strokeWidth="3" />
          {/* Eyes stalks */}
          <circle cx="50" cy="48" r="8" fill="#ffffff" stroke="#991b1b" strokeWidth="2" />
          <circle cx="70" cy="48" r="8" fill="#ffffff" stroke="#991b1b" strokeWidth="2" />
          <circle cx="50" cy="48" r="4" fill="#1f2937" />
          <circle cx="70" cy="48" r="4" fill="#1f2937" />
          <circle cx="52" cy="46" r="1.5" fill="#ffffff" />
          <circle cx="72" cy="46" r="1.5" fill="#ffffff" />
          {/* Big happy smile */}
          <path d="M48 76 Q60 90 72 76" stroke="#991b1b" strokeWidth="3" strokeLinecap="round" fill="#b91c1c" />
        </svg>
      );

    case 'lalat':
      return (
        <svg viewBox="0 0 120 120" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          {/* Housefly */}
          <ellipse cx="60" cy="106" rx="30" ry="6" fill="#cbd5e1" opacity="0.5" />
          {/* Wings */}
          <ellipse cx="38" cy="46" rx="26" ry="14" transform="rotate(-30 38 46)" fill="#e0f2fe" stroke="#38bdf8" strokeWidth="2" opacity="0.85" />
          <ellipse cx="82" cy="46" rx="26" ry="14" transform="rotate(30 82 46)" fill="#e0f2fe" stroke="#38bdf8" strokeWidth="2" opacity="0.85" />
          {/* Legs */}
          <path d="M42 66 L24 74 L18 88" stroke="#1e293b" strokeWidth="3" strokeLinecap="round" />
          <path d="M42 78 L26 92 L22 102" stroke="#1e293b" strokeWidth="3" strokeLinecap="round" />
          <path d="M78 66 L96 74 L102 88" stroke="#1e293b" strokeWidth="3" strokeLinecap="round" />
          <path d="M78 78 L94 92 L98 102" stroke="#1e293b" strokeWidth="3" strokeLinecap="round" />
          {/* Body */}
          <ellipse cx="60" cy="74" rx="16" ry="22" fill="#334155" stroke="#0f172a" strokeWidth="2.5" />
          {/* Head & Red Eyes */}
          <ellipse cx="60" cy="50" rx="14" ry="12" fill="#1e293b" />
          <ellipse cx="48" cy="48" rx="8" ry="10" fill="#dc2626" stroke="#991b1b" strokeWidth="2" />
          <ellipse cx="72" cy="48" rx="8" ry="10" fill="#dc2626" stroke="#991b1b" strokeWidth="2" />
          <circle cx="46" cy="45" r="2" fill="#fca5a5" />
          <circle cx="70" cy="45" r="2" fill="#fca5a5" />
          {/* Antenna */}
          <line x1="56" y1="40" x2="52" y2="30" stroke="#0f172a" strokeWidth="2" strokeLinecap="round" />
          <line x1="64" y1="40" x2="68" y2="30" stroke="#0f172a" strokeWidth="2" strokeLinecap="round" />
        </svg>
      );

    case 'lapan':
      return (
        <svg viewBox="0 0 120 120" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          {/* Stylized Number 8 matching worksheet */}
          <ellipse cx="60" cy="110" rx="30" ry="6" fill="#cbd5e1" opacity="0.5" />
          {/* Top circle */}
          <circle cx="60" cy="42" r="24" fill="#f472b6" stroke="#831843" strokeWidth="5" />
          <circle cx="60" cy="42" r="11" fill="#ffffff" stroke="#831843" strokeWidth="4" />
          {/* Bottom circle */}
          <circle cx="60" cy="80" r="28" fill="#ec4899" stroke="#831843" strokeWidth="5" />
          <circle cx="60" cy="80" r="13" fill="#ffffff" stroke="#831843" strokeWidth="4" />
          {/* Highlights & Stripes */}
          <path d="M48 30 Q56 22 68 24" stroke="#ffffff" strokeWidth="3" strokeLinecap="round" fill="none" />
          <path d="M44 68 Q56 58 72 62" stroke="#ffffff" strokeWidth="3.5" strokeLinecap="round" fill="none" />
        </svg>
      );

    case 'lebah':
      return (
        <svg viewBox="0 0 120 120" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          {/* Honeybee */}
          <ellipse cx="60" cy="108" rx="28" ry="6" fill="#cbd5e1" opacity="0.5" />
          {/* Wings */}
          <ellipse cx="48" cy="36" rx="20" ry="12" transform="rotate(-40 48 36)" fill="#e0f2fe" stroke="#38bdf8" strokeWidth="2" opacity="0.8" />
          <ellipse cx="72" cy="34" rx="20" ry="12" transform="rotate(30 72 34)" fill="#e0f2fe" stroke="#38bdf8" strokeWidth="2" opacity="0.8" />
          {/* Body Stripes */}
          <g>
            <ellipse cx="60" cy="72" rx="26" ry="20" fill="#facc15" stroke="#713f12" strokeWidth="3" />
            <path d="M52 54 L52 90" stroke="#1f2937" strokeWidth="7" />
            <path d="M68 54 L68 90" stroke="#1f2937" strokeWidth="7" />
            <polygon points="85,72 95,72 85,76" fill="#1f2937" />
          </g>
          {/* Head & Face */}
          <circle cx="36" cy="68" r="14" fill="#fef08a" stroke="#713f12" strokeWidth="2.5" />
          <circle cx="32" cy="65" r="3" fill="#1f2937" />
          <circle cx="33" cy="64" r="1" fill="#ffffff" />
          <path d="M28 73 Q34 77 38 73" stroke="#713f12" strokeWidth="2" strokeLinecap="round" />
          {/* Antenna */}
          <path d="M34 55 Q30 42 22 46" stroke="#1f2937" strokeWidth="2.5" strokeLinecap="round" fill="none" />
          <circle cx="22" cy="46" r="3" fill="#1f2937" />
        </svg>
      );

    case 'lemon':
      return (
        <svg viewBox="0 0 120 120" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          {/* Lemon and slice */}
          <ellipse cx="60" cy="108" rx="38" ry="6" fill="#cbd5e1" opacity="0.5" />
          {/* Whole Lemon behind */}
          <path d="M56 30 C76 22 96 36 98 56 C100 76 86 92 66 94 C56 94 48 88 48 88 C48 88 56 60 56 30 Z" fill="#facc15" stroke="#a16207" strokeWidth="2.5" />
          {/* Lemon Slice Front */}
          <circle cx="48" cy="70" r="28" fill="#fef08a" stroke="#ca8a04" strokeWidth="4" />
          <circle cx="48" cy="70" r="23" fill="#fde047" stroke="#eab308" strokeWidth="2" />
          {/* Segments */}
          <g stroke="#ffffff" strokeWidth="2" fill="#fef9c3">
            <path d="M48 70 L48 50 A20 20 0 0 1 64 58 Z" />
            <path d="M48 70 L64 58 A20 20 0 0 1 68 76 Z" />
            <path d="M48 70 L68 76 A20 20 0 0 1 54 88 Z" />
            <path d="M48 70 L54 88 A20 20 0 0 1 36 84 Z" />
            <path d="M48 70 L36 84 A20 20 0 0 1 30 66 Z" />
            <path d="M48 70 L30 66 A20 20 0 0 1 48 50 Z" />
          </g>
          <circle cx="48" cy="70" r="4" fill="#ffffff" />
        </svg>
      );

    case 'lipas':
      return (
        <svg viewBox="0 0 120 120" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          {/* Cockroach */}
          <ellipse cx="60" cy="108" rx="30" ry="6" fill="#cbd5e1" opacity="0.5" />
          {/* Legs */}
          <path d="M45 56 L26 44 L16 52" stroke="#78350f" strokeWidth="3" strokeLinecap="round" />
          <path d="M42 70 L20 72 L12 84" stroke="#78350f" strokeWidth="3" strokeLinecap="round" />
          <path d="M44 86 L22 96 L16 110" stroke="#78350f" strokeWidth="3" strokeLinecap="round" />
          <path d="M75 56 L94 44 L104 52" stroke="#78350f" strokeWidth="3" strokeLinecap="round" />
          <path d="M78 70 L100 72 L108 84" stroke="#78350f" strokeWidth="3" strokeLinecap="round" />
          <path d="M76 86 L98 96 L104 110" stroke="#78350f" strokeWidth="3" strokeLinecap="round" />
          {/* Body Carapace */}
          <ellipse cx="60" cy="75" rx="19" ry="28" fill="#92400e" stroke="#451a03" strokeWidth="2.5" />
          <ellipse cx="60" cy="68" rx="14" ry="18" fill="#b45309" />
          <line x1="60" y1="52" x2="60" y2="100" stroke="#451a03" strokeWidth="2" />
          {/* Head & Shield */}
          <ellipse cx="60" cy="46" rx="13" ry="9" fill="#78350f" stroke="#451a03" strokeWidth="2" />
          {/* Long curved antennae */}
          <path d="M54 42 Q32 18 18 16" stroke="#451a03" strokeWidth="2" strokeLinecap="round" fill="none" />
          <path d="M66 42 Q88 18 102 16" stroke="#451a03" strokeWidth="2" strokeLinecap="round" fill="none" />
        </svg>
      );

    case 'lipan':
      return (
        <svg viewBox="0 0 120 120" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          {/* Centipede curving */}
          <ellipse cx="60" cy="110" rx="36" ry="6" fill="#cbd5e1" opacity="0.5" />
          {/* Curving body segments */}
          <path d="M30 40 Q40 25 58 35 Q76 45 84 65 Q90 85 70 98 Q50 105 38 92" stroke="#b45309" strokeWidth="18" strokeLinecap="round" fill="none" />
          <path d="M30 40 Q40 25 58 35 Q76 45 84 65 Q90 85 70 98 Q50 105 38 92" stroke="#78350f" strokeWidth="3" strokeDasharray="3 7" fill="none" />
          {/* Tiny legs on sides */}
          <g stroke="#92400e" strokeWidth="2.5" strokeLinecap="round">
            <line x1="26" y1="35" x2="16" y2="30" />
            <line x1="38" y1="28" x2="34" y2="18" />
            <line x1="52" y1="26" x2="52" y2="14" />
            <line x1="68" y1="34" x2="76" y2="24" />
            <line x1="84" y1="52" x2="96" y2="46" />
            <line x1="90" y1="70" x2="104" y2="70" />
            <line x1="86" y1="88" x2="98" y2="94" />
            <line x1="68" y1="104" x2="74" y2="114" />
            <line x1="48" y1="104" x2="44" y2="116" />
          </g>
          {/* Antenna */}
          <line x1="28" y1="42" x2="14" y2="44" stroke="#451a03" strokeWidth="2" strokeLinecap="round" />
          <line x1="30" y1="36" x2="18" y2="32" stroke="#451a03" strokeWidth="2" strokeLinecap="round" />
        </svg>
      );

    case 'lilin':
      return (
        <svg viewBox="0 0 120 120" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          {/* Candle with flame */}
          <ellipse cx="60" cy="110" rx="30" ry="6" fill="#cbd5e1" opacity="0.5" />
          {/* Candle body */}
          <rect x="42" y="56" width="36" height="52" fill="#f8fafc" stroke="#94a3b8" strokeWidth="2.5" rx="4" />
          {/* Wax drips */}
          <path d="M42 66 C42 72 48 74 48 66" fill="#e2e8f0" stroke="#94a3b8" strokeWidth="1" />
          <path d="M60 68 C60 76 66 76 66 68" fill="#e2e8f0" stroke="#94a3b8" strokeWidth="1" />
          {/* Wick */}
          <line x1="60" y1="56" x2="60" y2="46" stroke="#334155" strokeWidth="3" strokeLinecap="round" />
          {/* Flame Halo & Tear flame */}
          <circle cx="60" cy="34" r="16" fill="#fef08a" opacity="0.4" />
          <path d="M60 16 C66 26 72 36 68 44 C64 50 56 50 52 44 C48 36 54 26 60 16 Z" fill="#f97316" stroke="#ea580c" strokeWidth="2" />
          <path d="M60 26 C63 32 66 38 64 43 C62 47 58 47 56 43 C54 38 57 32 60 26 Z" fill="#fde047" />
        </svg>
      );

    case 'lidah':
      return (
        <svg viewBox="0 0 120 120" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          {/* Open mouth with sticking-out tongue */}
          <ellipse cx="60" cy="108" rx="36" ry="6" fill="#cbd5e1" opacity="0.5" />
          {/* Big open mouth cavity */}
          <path d="M20 54 Q60 30 100 54 Q100 90 60 90 Q20 90 20 54 Z" fill="#450a0a" stroke="#881337" strokeWidth="3" />
          {/* Upper teeth */}
          <path d="M36 52 L36 58 L44 58 L44 52 L52 52 L52 58 L60 58 L60 52 L68 52 L68 58 L76 58 L76 52 L84 52 L84 58" stroke="#ffffff" strokeWidth="4" strokeLinecap="round" />
          {/* Big pink tongue poking out */}
          <path d="M38 68 C38 96 46 112 60 112 C74 112 82 96 82 68 Q60 76 38 68 Z" fill="#fb7185" stroke="#e11d48" strokeWidth="3" />
          {/* Tongue center groove */}
          <line x1="60" y1="74" x2="60" y2="102" stroke="#be123c" strokeWidth="2.5" strokeLinecap="round" />
        </svg>
      );

    case 'lobak':
      return (
        <svg viewBox="0 0 120 120" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          {/* Carrot */}
          <ellipse cx="60" cy="112" rx="32" ry="5" fill="#cbd5e1" opacity="0.5" />
          {/* Green leaves */}
          <path d="M60 48 C50 30 40 18 52 14 C62 26 62 40 60 48 Z" fill="#22c55e" stroke="#15803d" strokeWidth="2" />
          <path d="M60 48 C68 30 82 18 74 14 C64 26 62 40 60 48 Z" fill="#16a34a" stroke="#15803d" strokeWidth="2" />
          <path d="M60 48 C60 24 64 12 60 10 C56 12 58 24 60 48 Z" fill="#4ade80" stroke="#15803d" strokeWidth="2" />
          {/* Carrot conical root */}
          <path d="M42 48 Q60 44 78 48 C76 72 68 96 60 112 C52 96 44 72 42 48 Z" fill="#f97316" stroke="#c2410c" strokeWidth="3" />
          {/* Indent lines */}
          <line x1="50" y1="62" x2="64" y2="62" stroke="#ea580c" strokeWidth="2.5" strokeLinecap="round" />
          <line x1="56" y1="78" x2="70" y2="78" stroke="#ea580c" strokeWidth="2.5" strokeLinecap="round" />
          <line x1="54" y1="94" x2="64" y2="94" stroke="#ea580c" strokeWidth="2.5" strokeLinecap="round" />
        </svg>
      );

    case 'makan':
      return (
        <svg viewBox="0 0 120 120" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          {/* Boy eating yummy fried chicken leg */}
          <ellipse cx="60" cy="110" rx="30" ry="6" fill="#cbd5e1" opacity="0.5" />
          {/* Head & Face */}
          <circle cx="50" cy="38" r="20" fill="#fed7aa" stroke="#78350f" strokeWidth="2" />
          <path d="M30 36 C30 20 42 16 52 16 C64 16 72 24 70 36 C64 30 56 28 50 28 C42 28 34 32 30 36 Z" fill="#78350f" />
          {/* Eyes closed happily */}
          <path d="M42 36 Q46 42 50 36" stroke="#78350f" strokeWidth="2.5" strokeLinecap="round" fill="none" />
          <path d="M56 36 Q60 42 64 36" stroke="#78350f" strokeWidth="2.5" strokeLinecap="round" fill="none" />
          {/* Mouth biting chicken */}
          <ellipse cx="56" cy="46" rx="8" ry="6" fill="#dc2626" />
          {/* Shirt */}
          <path d="M32 60 Q52 56 72 60 L76 96 L28 96 Z" fill="#facc15" stroke="#ca8a04" strokeWidth="2" />
          {/* Fried Chicken Leg */}
          <g transform="translate(10, 0)">
            <ellipse cx="72" cy="54" rx="14" ry="10" transform="rotate(-25 72 54)" fill="#d97706" stroke="#78350f" strokeWidth="2.5" />
            <circle cx="70" cy="52" r="3" fill="#b45309" />
            {/* Bone */}
            <path d="M84 62 L94 68 C96 66 98 68 98 70 C96 72 94 72 92 70" stroke="#f1f5f9" strokeWidth="4" strokeLinecap="round" fill="none" />
          </g>
        </svg>
      );

    case 'mawar':
      return (
        <svg viewBox="0 0 120 120" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          {/* Red Rose flower */}
          <ellipse cx="60" cy="112" rx="26" ry="5" fill="#cbd5e1" opacity="0.5" />
          {/* Green Stem & Leaves */}
          <path d="M60 62 Q54 86 60 110" stroke="#16a34a" strokeWidth="4.5" strokeLinecap="round" fill="none" />
          <path d="M58 84 C44 80 38 88 42 94 C50 96 56 90 58 84 Z" fill="#22c55e" stroke="#15803d" strokeWidth="1.5" />
          <path d="M60 74 C74 70 80 78 76 84 C68 86 62 80 60 74 Z" fill="#22c55e" stroke="#15803d" strokeWidth="1.5" />
          {/* Thorns */}
          <polygon points="58,92 52,90 58,88" fill="#15803d" />
          <polygon points="60,78 66,76 60,74" fill="#15803d" />
          {/* Blooming Rose Petals */}
          <circle cx="60" cy="42" r="24" fill="#e11d48" stroke="#9f1239" strokeWidth="2.5" />
          <path d="M44 38 C42 54 54 62 60 62 C66 62 78 54 76 38 C74 24 64 24 60 28 C56 24 46 24 44 38 Z" fill="#f43f5e" stroke="#be123c" strokeWidth="2" />
          <path d="M50 40 C50 48 56 52 60 52 C64 52 70 48 70 40 C68 34 62 34 60 36 C58 34 52 34 50 40 Z" fill="#fb7185" />
          <circle cx="60" cy="40" r="4" fill="#881337" />
        </svg>
      );

    case 'malam':
      return (
        <svg viewBox="0 0 120 120" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          {/* Night Sky with Crescent Moon, Stars & City skyline */}
          <rect x="14" y="14" width="92" height="92" rx="16" fill="#0f172a" stroke="#334155" strokeWidth="3" />
          {/* Stars */}
          <circle cx="34" cy="30" r="2" fill="#fde047" />
          <circle cx="86" cy="36" r="2" fill="#fde047" />
          <circle cx="48" cy="50" r="1.5" fill="#fde047" />
          <circle cx="28" cy="62" r="1.5" fill="#fde047" />
          {/* Crescent Moon */}
          <path d="M72 24 C62 24 54 32 54 44 C54 56 64 64 74 64 C70 60 68 52 68 44 C68 34 72 28 72 24 Z" fill="#facc15" stroke="#eab308" strokeWidth="1.5" />
          {/* Buildings silhouette */}
          <rect x="22" y="66" width="22" height="40" fill="#1e293b" />
          <rect x="40" y="54" width="26" height="52" fill="#334155" />
          <rect x="62" y="60" width="22" height="46" fill="#1e293b" />
          <rect x="80" y="70" width="22" height="36" fill="#334155" />
          {/* Building Windows glowing */}
          <rect x="44" y="60" width="4" height="6" fill="#fef08a" />
          <rect x="52" y="60" width="4" height="6" fill="#fef08a" />
          <rect x="44" y="72" width="4" height="6" fill="#fef08a" />
          <rect x="52" y="72" width="4" height="6" fill="#fef08a" />
          <rect x="66" y="68" width="4" height="5" fill="#fef08a" />
          <rect x="74" y="68" width="4" height="5" fill="#fef08a" />
          <rect x="26" y="76" width="4" height="5" fill="#fef08a" />
        </svg>
      );

    default:
      return (
        <div className={`flex items-center justify-center bg-indigo-100 rounded-2xl border-2 border-indigo-200 text-indigo-700 font-bold ${className}`}>
          {wordId}
        </div>
      );
  }
};
