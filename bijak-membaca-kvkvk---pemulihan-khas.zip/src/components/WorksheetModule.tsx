import React, { useState } from 'react';
import { SukuKataItem, StudentProfile } from '../types';
import { LEMBARAN_WORDS } from '../data/wordsData';
import { WordImage } from './WordImage';
import { soundFx, sebutSukuKata, sebutEjaanPenuh } from '../utils/audio';
import { rekodKemajuanMurid } from '../utils/studentStore';
import confetti from 'canvas-confetti';
import {
  FileText,
  Volume2,
  CheckCircle2,
  Sparkles,
  HelpCircle,
  Eye,
  RotateCcw
} from 'lucide-react';

interface Props {
  activeStudent: StudentProfile;
  onUpdateStudent: (updated: StudentProfile) => void;
}

export const WorksheetModule: React.FC<Props> = ({ activeStudent, onUpdateStudent }) => {
  const [selectedWord, setSelectedWord] = useState<SukuKataItem | null>(null);
  const [showAnswers, setShowAnswers] = useState(false);
  const [studentAnswers, setStudentAnswers] = useState<Record<string, string>>({});

  const handleBoxClick = (item: SukuKataItem) => {
    setSelectedWord(item);
    soundFx.playPointerChime();
    sebutEjaanPenuh(item.suku1, item.suku2, item.word);
  };

  const handleTestWord = (item: SukuKataItem) => {
    soundFx.playCoinSound();
    confetti({ particleCount: 30, spread: 50, origin: { y: 0.7 } });
    sebutSukuKata(`Syabas! Ini ialah perkataan ${item.word}!`);

    const updated = rekodKemajuanMurid(
      activeStudent.id,
      'Ujian Ejaan',
      item.id,
      true,
      100,
      15
    );
    onUpdateStudent(updated);
  };

  return (
    <div className="rounded-3xl bg-white shadow-xl border-4 border-indigo-100 p-4 md:p-6 select-none">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-slate-100">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-3 py-1 rounded-full bg-amber-100 text-amber-900 text-xs font-bold uppercase tracking-wide">
              Lembaran Kerja KVKVK
            </span>
            <h2 className="text-xl md:text-2xl font-black text-slate-800 flex items-center gap-2">
              <span>Baca dan Tulis Jawapan yang Betul</span>
              <FileText className="w-5 h-5 text-amber-600" />
            </h2>
          </div>
          <p className="text-xs md:text-sm text-slate-500 mt-0.5">
            Salinan interaktif lembaran kerja asal berserta audio dan penunjuk sebutan.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowAnswers(!showAnswers)}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-bold transition cursor-pointer ${
              showAnswers
                ? 'bg-amber-100 text-amber-900 border-amber-300'
                : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
            }`}
          >
            <Eye className="w-3.5 h-3.5" />
            <span>{showAnswers ? 'Sembunyi Ejaan' : 'Papar Semua Ejaan'}</span>
          </button>
        </div>
      </div>

      {/* Top Word Bank Grid (as in the original worksheet) */}
      <div className="my-4 p-4 rounded-2xl bg-amber-50/70 border-2 border-amber-200">
        <div className="text-xs font-black uppercase text-amber-800 tracking-wider mb-2 text-center">
          Pilihan Jawapan (Bank Perkataan):
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center">
          {LEMBARAN_WORDS.map((w) => (
            <button
              key={w.id}
              onClick={() => {
                soundFx.playPointerChime();
                sebutSukuKata(w.word);
              }}
              className="py-1.5 px-3 rounded-xl bg-white border border-amber-200 shadow-2xs font-extrabold text-base md:text-lg text-slate-800 hover:border-amber-400 hover:bg-amber-100/40 transition cursor-pointer"
            >
              <span className="text-blue-600">{w.suku1}</span>
              <span className="text-rose-600">{w.suku2}</span>
            </button>
          ))}
        </div>
      </div>

      {/* 16 Worksheet Grid Cards (4x4 layout identical to the worksheet) */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4 mt-6">
        {LEMBARAN_WORDS.map((item) => {
          const isDikuasai = activeStudent.perkataanDikuasai.includes(item.id);

          return (
            <div
              key={item.id}
              onClick={() => handleBoxClick(item)}
              className="relative p-3 rounded-2xl border-2 border-blue-200 bg-white hover:border-blue-500 hover:shadow-lg transition-all flex flex-col items-center justify-between cursor-pointer group"
            >
              {/* Number tag */}
              <div className="w-full flex items-center justify-between">
                <span className="text-xs font-extrabold text-blue-800 bg-blue-100 px-2 py-0.5 rounded-md">
                  {item.nomborLembaran})
                </span>
                {isDikuasai && (
                  <span className="flex items-center gap-1 text-[10px] font-bold text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded-md border border-emerald-200">
                    <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                    <span>Dikuasai</span>
                  </span>
                )}
              </div>

              {/* Graphic */}
              <div className="py-2">
                <WordImage wordId={item.id} className="w-20 h-20 md:w-24 md:h-24 object-contain group-hover:scale-105 transition-transform" />
              </div>

              {/* Lined Writing Box as in primary school exercise books */}
              <div className="w-full mt-2 pt-2 border-t-2 border-blue-400 bg-blue-50/30 rounded-b-xl text-center">
                {showAnswers || isDikuasai ? (
                  <div className="text-xl md:text-2xl font-black py-1">
                    <span className="text-blue-600">{item.suku1}</span>
                    <span className="text-rose-600">{item.suku2}</span>
                  </div>
                ) : (
                  <div className="py-2 text-xs font-bold text-slate-400 border-b border-dashed border-blue-300">
                    Ketik untuk eja
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Selected Word Detail Bottom Sheet / Modal */}
      {selectedWord && (
        <div className="mt-6 p-5 rounded-3xl bg-gradient-to-r from-blue-50 to-indigo-50 border-2 border-blue-200 flex flex-col md:flex-row items-center justify-between gap-4 animate-fade-in">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-white rounded-2xl shadow-md border border-blue-100">
              <WordImage wordId={selectedWord.id} className="w-16 h-16 object-contain" />
            </div>
            <div>
              <div className="text-xs font-bold text-blue-700 uppercase">
                Perkataan Lembaran #{selectedWord.nomborLembaran}:
              </div>
              <div className="text-3xl font-black">
                <span className="text-blue-600">{selectedWord.suku1}</span>
                <span className="text-rose-600">{selectedWord.suku2}</span>
              </div>
              <p className="text-xs text-slate-600 mt-1 max-w-md">
                {selectedWord.makna}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => sebutEjaanPenuh(selectedWord.suku1, selectedWord.suku2, selectedWord.word)}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-white border border-blue-200 text-blue-700 font-bold text-xs shadow-xs hover:bg-blue-50 transition cursor-pointer"
            >
              <Volume2 className="w-4 h-4" />
              <span>Dengar Sebutan</span>
            </button>
            <button
              onClick={() => handleTestWord(selectedWord)}
              className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 text-white font-bold text-xs shadow-md hover:from-emerald-600 hover:to-teal-700 active:scale-95 transition cursor-pointer"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>Tandakan Dikuasai</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
