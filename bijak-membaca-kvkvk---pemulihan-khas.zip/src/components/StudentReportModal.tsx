import React, { useState } from 'react';
import { StudentProfile } from '../types';
import { LEMBARAN_WORDS } from '../data/wordsData';
import { WordImage } from './WordImage';
import { TAHAP_DESKRIPSI, saveStudents, loadStudents, setActiveStudentId } from '../utils/studentStore';
import {
  Trophy,
  Star,
  Coins,
  CheckCircle2,
  AlertCircle,
  Printer,
  UserPlus,
  UserCheck,
  Calendar,
  Award,
  BookOpen,
  X,
  FileCheck,
  ChevronRight
} from 'lucide-react';

interface Props {
  activeStudent: StudentProfile;
  students: StudentProfile[];
  onSelectStudent: (student: StudentProfile) => void;
  onRefreshStudents: () => void;
  onClose: () => void;
}

export const StudentReportModal: React.FC<Props> = ({
  activeStudent,
  students,
  onSelectStudent,
  onRefreshStudents,
  onClose,
}) => {
  const [activeTab, setActiveTab] = useState<'laporan' | 'tukar-murid' | 'tambah-murid'>('laporan');

  // Form tambah murid
  const [namaBaru, setNamaBaru] = useState('');
  const [kelasBaru, setKelasBaru] = useState('2 Cerdik');
  const [avatarBaru, setAvatarBaru] = useState('👦');

  const dikuasaiCount = activeStudent.perkataanDikuasai.length;
  const peratusan = Math.round((dikuasaiCount / LEMBARAN_WORDS.length) * 100);
  const tahapInfo = TAHAP_DESKRIPSI[activeStudent.tahapPenguasaan] || TAHAP_DESKRIPSI[1];

  const handlePrint = () => {
    window.print();
  };

  const handleTambahMurid = (e: React.FormEvent) => {
    e.preventDefault();
    if (!namaBaru.trim()) return;

    const newStudent: StudentProfile = {
      id: `s-${Date.now()}`,
      nama: namaBaru.trim(),
      kelas: kelasBaru,
      avatar: avatarBaru,
      tarikhDaftar: new Date().toISOString().split('T')[0],
      bintangTerkumpul: 0,
      syilingMario: 0,
      perkataanDikuasai: [],
      perkataanBimbingan: [],
      tahapPenguasaan: 1,
      rekodAktiviti: [],
    };

    const currentList = loadStudents();
    const updated = [...currentList, newStudent];
    saveStudents(updated);
    setActiveStudentId(newStudent.id);
    onSelectStudent(newStudent);
    onRefreshStudents();
    setActiveTab('laporan');
    setNamaBaru('');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-3 md:p-6 overflow-y-auto">
      <div className="w-full max-w-4xl bg-white rounded-3xl shadow-2xl border-4 border-indigo-200 overflow-hidden my-auto max-h-[92vh] flex flex-col">
        {/* Modal Top Bar */}
        <div className="px-6 py-4 bg-gradient-to-r from-indigo-700 via-indigo-600 to-violet-700 text-white flex items-center justify-between no-print shrink-0">
          <div className="flex items-center gap-3">
            <Award className="w-6 h-6 text-amber-300" />
            <div>
              <h2 className="font-black text-lg md:text-xl">
                Sistem Rekod Perkembangan Murid Pemulihan Khas
              </h2>
              <p className="text-xs text-indigo-100">
                Dokumen Standard Penguasaan Kemahiran Membaca & Mengeja KVKVK
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl bg-white/20 hover:bg-white/30 text-white transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Tabs inside modal */}
        <div className="px-6 py-2.5 bg-indigo-50/70 border-b border-indigo-100 flex items-center justify-between no-print shrink-0">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveTab('laporan')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
                activeTab === 'laporan'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 bg-white/80'
              }`}
            >
              Slip Laporan Murid
            </button>
            <button
              onClick={() => setActiveTab('tukar-murid')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
                activeTab === 'tukar-murid'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 bg-white/80'
              }`}
            >
              Senarai Murid ({students.length})
            </button>
            <button
              onClick={() => setActiveTab('tambah-murid')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-1 ${
                activeTab === 'tambah-murid'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 bg-white/80'
              }`}
            >
              <UserPlus className="w-3.5 h-3.5" />
              <span>Daftar Murid Baru</span>
            </button>
          </div>

          {activeTab === 'laporan' && (
            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white border border-slate-300 text-slate-700 text-xs font-bold shadow-xs hover:bg-slate-50 transition cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5 text-indigo-600" />
              <span>Cetak Slip Penilaian</span>
            </button>
          )}
        </div>

        {/* Modal Body (Scrollable) */}
        <div className="p-6 overflow-y-auto flex-1">
          {activeTab === 'laporan' && (
            <div className="space-y-6">
              {/* Official Header for Print / Display */}
              <div className="text-center pb-4 border-b-2 border-slate-200">
                <div className="text-xs font-black tracking-widest text-slate-500 uppercase">
                  KEMENTERIAN PENDIDIKAN MALAYSIA
                </div>
                <h3 className="text-xl md:text-2xl font-black text-slate-800">
                  REKOD PERKEMBANGAN MURID PEMULIHAN KHAS
                </h3>
                <p className="text-xs text-slate-600 font-bold">
                  Kemahiran 6: Perkataan Mengandungi Suku Kata KVKVK (16 Perkataan Lembaran)
                </p>
              </div>

              {/* Student Summary Card */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4 p-4 rounded-2xl bg-indigo-50/50 border border-indigo-100">
                <div className="flex items-center gap-3">
                  <div className="text-4xl p-2 rounded-2xl bg-white shadow-xs border border-indigo-100">
                    {activeStudent.avatar}
                  </div>
                  <div>
                    <div className="text-xs text-slate-500 font-bold">Nama Murid:</div>
                    <div className="font-black text-slate-800 text-base">
                      {activeStudent.nama}
                    </div>
                    <div className="text-xs font-bold text-indigo-600">
                      Kelas: {activeStudent.kelas}
                    </div>
                  </div>
                </div>

                <div>
                  <div className="text-xs text-slate-500 font-bold">Tahap Penguasaan:</div>
                  <div className="inline-block mt-0.5 px-2.5 py-1 rounded-lg bg-indigo-600 text-white font-black text-sm">
                    TP {activeStudent.tahapPenguasaan}
                  </div>
                  <div className="text-[11px] text-slate-600 font-bold mt-1">
                    {tahapInfo.tajuk}
                  </div>
                </div>

                <div>
                  <div className="text-xs text-slate-500 font-bold">Peratus Penguasaan:</div>
                  <div className="text-2xl font-black text-emerald-600 mt-0.5">
                    {peratusan}%
                  </div>
                  <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden mt-1">
                    <div
                      className="bg-emerald-500 h-full rounded-full transition-all duration-500"
                      style={{ width: `${peratusan}%` }}
                    />
                  </div>
                </div>

                <div className="flex flex-col justify-center">
                  <div className="flex items-center gap-3 text-xs font-bold text-slate-700">
                    <span className="flex items-center gap-1 text-amber-600">
                      <Star className="w-4 h-4 fill-amber-400 text-amber-500" />
                      <span>{activeStudent.bintangTerkumpul} Bintang</span>
                    </span>
                    <span className="flex items-center gap-1 text-amber-700">
                      <Coins className="w-4 h-4 text-amber-600" />
                      <span>{activeStudent.syilingMario} Syiling</span>
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-400 mt-1">
                    Didaftar: {activeStudent.tarikhDaftar}
                  </div>
                </div>
              </div>

              {/* Tahap Penguasaan Description */}
              <div className="p-4 rounded-2xl bg-amber-50/80 border border-amber-200">
                <div className="text-xs font-black text-amber-900 uppercase">
                  Huraian Standard Prestasi (KSSR Pemulihan Khas):
                </div>
                <p className="text-xs md:text-sm text-slate-700 mt-1">
                  {tahapInfo.huraian}
                </p>
              </div>

              {/* Word Mastery Matrix (All 16 words from worksheet) */}
              <div>
                <div className="flex items-center justify-between mb-3">
                  <h4 className="font-black text-sm text-slate-800 uppercase tracking-wide">
                    Matriks Penguasaan 16 Perkataan KVKVK Lembaran Kerja:
                  </h4>
                  <div className="text-xs font-bold text-slate-500">
                    Dikuasai: <span className="text-emerald-600 font-black">{dikuasaiCount}</span> / 16
                  </div>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                  {LEMBARAN_WORDS.map((w) => {
                    const isMastered = activeStudent.perkataanDikuasai.includes(w.id);
                    const isNeedsHelp = activeStudent.perkataanBimbingan.includes(w.id);

                    return (
                      <div
                        key={w.id}
                        className={`p-2.5 rounded-xl border flex items-center justify-between ${
                          isMastered
                            ? 'bg-emerald-50/80 border-emerald-300 text-emerald-900'
                            : isNeedsHelp
                            ? 'bg-amber-50 border-amber-300 text-amber-900'
                            : 'bg-slate-50 border-slate-200 text-slate-600'
                        }`}
                      >
                        <div className="flex items-center gap-2">
                          <WordImage wordId={w.id} className="w-8 h-8 object-contain shrink-0" />
                          <div>
                            <div className="font-black text-xs">
                              {w.nomborLembaran}. {w.word}
                            </div>
                            <div className="text-[10px] text-slate-500">
                              {w.suku1}-{w.suku2}
                            </div>
                          </div>
                        </div>

                        {isMastered ? (
                          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                        ) : isNeedsHelp ? (
                          <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
                        ) : (
                          <span className="text-[10px] text-slate-400 font-bold shrink-0">
                            Belum Uji
                          </span>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Recent Activity Log */}
              <div>
                <h4 className="font-black text-sm text-slate-800 uppercase tracking-wide mb-2">
                  Log Aktiviti Gamifikasi Terkini:
                </h4>
                {activeStudent.rekodAktiviti && activeStudent.rekodAktiviti.length > 0 ? (
                  <div className="divide-y divide-slate-100 rounded-2xl border border-slate-200 overflow-hidden">
                    {activeStudent.rekodAktiviti.slice(0, 5).map((log) => (
                      <div key={log.id} className="px-4 py-2.5 bg-white flex items-center justify-between text-xs">
                        <div className="flex items-center gap-2.5">
                          <span className="px-2 py-0.5 rounded-md bg-indigo-100 text-indigo-800 font-bold">
                            {log.aktiviti}
                          </span>
                          <span className="font-extrabold text-slate-800">
                            Perkataan: "{log.perkataan}"
                          </span>
                        </div>
                        <div className="flex items-center gap-3 text-slate-500">
                          <span className="font-bold text-emerald-600">Markah: {log.markah}</span>
                          <span>{log.tarikh}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="p-4 rounded-xl bg-slate-50 text-slate-400 text-xs text-center border border-slate-200">
                    Belum ada aktiviti direkodkan untuk murid ini. Main mana-mana permainan di atas untuk merekod secara automatik!
                  </div>
                )}
              </div>

              {/* Official Sign-off Box for Print */}
              <div className="pt-8 border-t-2 border-slate-200 grid grid-cols-2 gap-8 text-center print-only">
                <div className="space-y-12">
                  <div className="text-xs text-slate-600 font-bold">
                    Disahkan Oleh Guru Pemulihan Khas:
                  </div>
                  <div className="border-t border-slate-400 pt-1 text-xs font-bold text-slate-800">
                    (......................................................)
                    <br />
                    Guru Pemulihan Khas
                  </div>
                </div>

                <div className="space-y-12">
                  <div className="text-xs text-slate-600 font-bold">
                    Tandatangan Ibu Bapa / Penjaga:
                  </div>
                  <div className="border-t border-slate-400 pt-1 text-xs font-bold text-slate-800">
                    (......................................................)
                    <br />
                    Ibu Bapa / Penjaga
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'tukar-murid' && (
            <div className="space-y-4">
              <div className="text-sm text-slate-600">
                Pilih murid aktif untuk sesi pembelajaran atau cetakan slip perkembangan:
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {students.map((st) => (
                  <div
                    key={st.id}
                    onClick={() => {
                      setActiveStudentId(st.id);
                      onSelectStudent(st);
                      setActiveTab('laporan');
                    }}
                    className={`p-4 rounded-2xl border-2 flex items-center justify-between transition cursor-pointer ${
                      st.id === activeStudent.id
                        ? 'bg-indigo-50 border-indigo-600 shadow-md ring-2 ring-indigo-200'
                        : 'bg-white border-slate-200 hover:border-indigo-300'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <span className="text-3xl">{st.avatar}</span>
                      <div>
                        <div className="font-black text-slate-800 text-sm">
                          {st.nama}
                        </div>
                        <div className="text-xs text-slate-500 font-bold">
                          Kelas: {st.kelas} • TP {st.tahapPenguasaan}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      {st.id === activeStudent.id && (
                        <span className="px-2 py-0.5 rounded-full bg-indigo-600 text-white text-[10px] font-bold">
                          Aktif
                        </span>
                      )}
                      <ChevronRight className="w-4 h-4 text-slate-400" />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'tambah-murid' && (
            <form onSubmit={handleTambahMurid} className="max-w-md mx-auto space-y-4 py-4">
              <div className="text-center pb-2">
                <h4 className="font-black text-lg text-slate-800">
                  Daftar Profil Murid Pemulihan Baru
                </h4>
                <p className="text-xs text-slate-500">
                  Data perkembangan akan direkod secara automatik setiap kali murid bermain aktiviti.
                </p>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Nama Murid:
                </label>
                <input
                  type="text"
                  required
                  placeholder="cth: Siti Nurhaliza binti Ahmad"
                  value={namaBaru}
                  onChange={(e) => setNamaBaru(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-300 text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Kelas Murid:
                </label>
                <input
                  type="text"
                  required
                  placeholder="cth: 2 Cerdik / 3 Amanah"
                  value={kelasBaru}
                  onChange={(e) => setKelasBaru(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-300 text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Pilih Avatar Murid:
                </label>
                <div className="flex gap-3 justify-center py-2">
                  {['👦', '👧', '🧒', '🧑', '🐱', '🚀', '🌟'].map((emoji) => (
                    <button
                      type="button"
                      key={emoji}
                      onClick={() => setAvatarBaru(emoji)}
                      className={`text-2xl p-2 rounded-xl border-2 transition cursor-pointer ${
                        avatarBaru === emoji
                          ? 'border-indigo-600 bg-indigo-50 scale-110'
                          : 'border-slate-200 hover:bg-slate-50'
                      }`}
                    >
                      {emoji}
                    </button>
                  ))}
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-3 rounded-2xl bg-indigo-600 text-white font-black text-sm shadow-md hover:bg-indigo-700 active:scale-95 transition cursor-pointer mt-4"
              >
                Simpan & Aktifkan Murid
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
