import React, { useState, useEffect, useCallback, useRef } from 'react';
import { SukuKataItem, StudentProfile } from '../types';
import { LEMBARAN_WORDS } from '../data/wordsData';
import { WordImage } from './WordImage';
import { soundFx, sebutSukuKata } from '../utils/audio';
import { rekodKemajuanMurid } from '../utils/studentStore';
import confetti from 'canvas-confetti';
import {
  Compass,
  ArrowUp,
  ArrowDown,
  ArrowLeft,
  ArrowRight,
  RotateCcw,
  Sparkles,
  Trophy,
  Volume2,
  CheckCircle2,
  Lock,
  DoorOpen
} from 'lucide-react';

interface Props {
  activeStudent: StudentProfile;
  onUpdateStudent: (updated: StudentProfile) => void;
}

// 7x7 Grid Maze
const GRID_SIZE = 7;

// 1 represents wall, 0 represents walkable path
const MAZE_MAPS = [
  [
    [0, 0, 0, 1, 0, 0, 0],
    [1, 1, 0, 1, 0, 1, 0],
    [0, 0, 0, 0, 0, 1, 0],
    [0, 1, 1, 1, 0, 0, 0],
    [0, 0, 0, 1, 1, 1, 0],
    [1, 1, 0, 0, 0, 0, 0],
    [0, 0, 0, 1, 1, 1, 0],
  ],
  [
    [0, 0, 1, 0, 0, 0, 0],
    [0, 1, 1, 0, 1, 1, 0],
    [0, 0, 0, 0, 0, 1, 0],
    [1, 1, 0, 1, 0, 0, 0],
    [0, 0, 0, 1, 0, 1, 1],
    [0, 1, 0, 0, 0, 0, 0],
    [0, 1, 1, 1, 1, 1, 0],
  ],
];

export const MazeRunnerModule: React.FC<Props> = ({ activeStudent, onUpdateStudent }) => {
  const [wordIndex, setWordIndex] = useState(0);
  const targetWord = LEMBARAN_WORDS[wordIndex];

  const [playerPos, setPlayerPos] = useState({ x: 0, y: 0 });
  const [suku1Collected, setSuku1Collected] = useState(false);
  const [suku2Collected, setSuku2Collected] = useState(false);
  const [isCompleted, setIsCompleted] = useState(false);
  const [movesCount, setMovesCount] = useState(0);
  const [timerSeconds, setTimerSeconds] = useState(0);
  const [isActive, setIsActive] = useState(true);

  // Positions on 7x7 grid
  // Player starts at (0, 0)
  // Suku 1 at (2, 2)
  // Suku 2 at (4, 4) or (5, 2)
  // Exit Gate at (6, 6)
  const suku1Pos = { x: 2, y: 2 };
  const suku2Pos = { x: 5, y: 3 };
  const goalPos = { x: 6, y: 6 };

  const currentMaze = MAZE_MAPS[wordIndex % MAZE_MAPS.length];

  // Timer
  useEffect(() => {
    if (!isActive || isCompleted) return;
    const interval = setInterval(() => {
      setTimerSeconds((prev) => prev + 1);
    }, 1000);
    return () => clearInterval(interval);
  }, [isActive, isCompleted]);

  // Reset or initialize level
  const initLevel = useCallback(
    (index: number) => {
      setWordIndex(index);
      setPlayerPos({ x: 0, y: 0 });
      setSuku1Collected(false);
      setSuku2Collected(false);
      setIsCompleted(false);
      setMovesCount(0);
      setTimerSeconds(0);
      setIsActive(true);

      const word = LEMBARAN_WORDS[index];
      sebutSukuKata(`Misi Maze: Kumpul suku kata '${word.suku1}' dan '${word.suku2}' untuk perkataan ${word.word}!`);
    },
    []
  );

  useEffect(() => {
    initLevel(wordIndex);
  }, [initLevel]);

  // Movement Logic
  const movePlayer = useCallback(
    (dx: number, dy: number) => {
      if (isCompleted) return;

      const newX = playerPos.x + dx;
      const newY = playerPos.y + dy;

      // Check bounds
      if (newX < 0 || newX >= GRID_SIZE || newY < 0 || newY >= GRID_SIZE) {
        return;
      }

      // Check walls
      if (currentMaze[newY][newX] === 1) {
        soundFx.playWrongBuzzer();
        return;
      }

      // Valid move
      soundFx.playStepSound();
      setPlayerPos({ x: newX, y: newY });
      setMovesCount((prev) => prev + 1);

      // Check Suku 1
      if (newX === suku1Pos.x && newY === suku1Pos.y && !suku1Collected) {
        setSuku1Collected(true);
        soundFx.playCoinSound();
        sebutSukuKata(targetWord.suku1);
      }

      // Check Suku 2
      if (newX === suku2Pos.x && newY === suku2Pos.y && !suku2Collected) {
        if (!suku1Collected) {
          soundFx.playWrongBuzzer();
          sebutSukuKata(`Kumpul '${targetWord.suku1}' dahulu ya?`);
          return;
        }
        setSuku2Collected(true);
        soundFx.playCoinSound();
        sebutSukuKata(targetWord.suku2);
      }

      // Check Goal
      if (newX === goalPos.x && newY === goalPos.y) {
        if (suku1Collected && suku2Collected) {
          setIsCompleted(true);
          soundFx.playSuccessFanfare();
          confetti({ particleCount: 50, spread: 70, origin: { y: 0.6 } });
          sebutSukuKata(`Tahniah! Awak berjaya melengkapkan perkataan ${targetWord.word}!`);

          const updated = rekodKemajuanMurid(
            activeStudent.id,
            'Maze Runner',
            targetWord.id,
            true,
            100,
            timerSeconds
          );
          onUpdateStudent(updated);
        } else {
          soundFx.playWrongBuzzer();
          sebutSukuKata(`Pintu terkunci! Lengkapkan ejaan ${targetWord.word} dahulu ya?`);
        }
      }
    },
    [
      playerPos,
      currentMaze,
      isCompleted,
      suku1Collected,
      suku2Collected,
      targetWord,
      timerSeconds,
      activeStudent.id,
      onUpdateStudent,
    ]
  );

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (['ArrowUp', 'KeyW'].includes(e.code)) {
        e.preventDefault();
        movePlayer(0, -1);
      } else if (['ArrowDown', 'KeyS'].includes(e.code)) {
        e.preventDefault();
        movePlayer(0, 1);
      } else if (['ArrowLeft', 'KeyA'].includes(e.code)) {
        e.preventDefault();
        movePlayer(-1, 0);
      } else if (['ArrowRight', 'KeyD'].includes(e.code)) {
        e.preventDefault();
        movePlayer(1, 0);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [movePlayer]);

  const nextMaze = () => {
    const nextIdx = (wordIndex + 1) % LEMBARAN_WORDS.length;
    initLevel(nextIdx);
  };

  return (
    <div className="rounded-3xl bg-white shadow-xl border-4 border-indigo-100 p-4 md:p-6 select-none">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-slate-100">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-3 py-1 rounded-full bg-emerald-100 text-emerald-800 text-xs font-bold uppercase tracking-wide">
              Aktiviti 2
            </span>
            <h2 className="text-xl md:text-2xl font-black text-slate-800 flex items-center gap-2">
              <span>Maze Runner KVKVK</span>
              <Compass className="w-5 h-5 text-emerald-500" />
            </h2>
          </div>
          <p className="text-xs md:text-sm text-slate-500 mt-0.5">
            Jalankan watak dalam pagar sesat untuk mengumpul suku kata perkataan sasaran!
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => initLevel(wordIndex)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-slate-200 text-slate-600 text-xs font-bold hover:bg-slate-50 transition cursor-pointer"
            title="Ulang semula maze ini"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Mula Semula</span>
          </button>
        </div>
      </div>

      {/* Target Mission Card */}
      <div className="my-4 p-4 rounded-2xl bg-gradient-to-r from-emerald-50 via-teal-50 to-indigo-50 border-2 border-emerald-200 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="p-2 rounded-2xl bg-white shadow-md border border-emerald-100">
            <WordImage wordId={targetWord.id} className="w-16 h-16 object-contain" />
          </div>
          <div>
            <div className="text-xs font-bold text-emerald-800 uppercase tracking-wide">
              Perkataan Sasaran:
            </div>
            <div className="text-2xl font-black text-slate-800 flex items-center gap-2">
              <span>{targetWord.word}</span>
              <button
                onClick={() => sebutSukuKata(`Misi kumpul suku kata ${targetWord.word}`)}
                className="p-1 rounded-lg text-emerald-600 hover:bg-emerald-100 transition cursor-pointer"
              >
                <Volume2 className="w-4 h-4" />
              </button>
            </div>
            <div className="text-xs text-slate-600 mt-0.5">
              Urutan: Suku awal <span className="font-bold text-blue-600">[{targetWord.suku1}]</span> ➔ Suku akhir <span className="font-bold text-rose-600">[{targetWord.suku2}]</span>
            </div>
          </div>
        </div>

        {/* Collection Status Badges */}
        <div className="flex items-center gap-2">
          <div
            className={`px-3 py-1.5 rounded-xl font-black text-sm border-2 flex items-center gap-1.5 ${
              suku1Collected
                ? 'bg-blue-600 text-white border-blue-700 shadow-md'
                : 'bg-white text-blue-400 border-dashed border-blue-300'
            }`}
          >
            {suku1Collected ? <CheckCircle2 className="w-4 h-4" /> : <span>1</span>}
            <span>{targetWord.suku1}</span>
          </div>

          <span className="text-slate-400 font-bold">+</span>

          <div
            className={`px-3 py-1.5 rounded-xl font-black text-sm border-2 flex items-center gap-1.5 ${
              suku2Collected
                ? 'bg-rose-600 text-white border-rose-700 shadow-md'
                : 'bg-white text-rose-400 border-dashed border-rose-300'
            }`}
          >
            {suku2Collected ? <CheckCircle2 className="w-4 h-4" /> : <span>2</span>}
            <span>{targetWord.suku2}</span>
          </div>

          <div
            className={`px-3 py-1.5 rounded-xl font-bold text-xs border flex items-center gap-1 ${
              suku1Collected && suku2Collected
                ? 'bg-amber-100 text-amber-800 border-amber-300 animate-pulse'
                : 'bg-slate-100 text-slate-500 border-slate-200'
            }`}
          >
            {suku1Collected && suku2Collected ? <DoorOpen className="w-4 h-4 text-emerald-600" /> : <Lock className="w-4 h-4" />}
            <span>{suku1Collected && suku2Collected ? 'Pintu Terbuka!' : 'Pintu Berkunci'}</span>
          </div>
        </div>
      </div>

      {/* Main Game Arena */}
      <div className="flex flex-col lg:flex-row items-center justify-center gap-6 mt-4">
        {/* Maze Grid */}
        <div className="relative p-3 rounded-3xl bg-slate-800 shadow-2xl border-4 border-slate-700">
          <div
            className="grid gap-1.5"
            style={{
              gridTemplateColumns: `repeat(${GRID_SIZE}, minmax(0, 1fr))`,
              width: 'min(80vw, 360px)',
              height: 'min(80vw, 360px)',
            }}
          >
            {currentMaze.map((row, rIdx) =>
              row.map((cell, cIdx) => {
                const isPlayer = playerPos.x === cIdx && playerPos.y === rIdx;
                const isSuku1 = suku1Pos.x === cIdx && suku1Pos.y === rIdx && !suku1Collected;
                const isSuku2 = suku2Pos.x === cIdx && suku2Pos.y === rIdx && !suku2Collected;
                const isGoal = goalPos.x === cIdx && goalPos.y === rIdx;
                const isWall = cell === 1;

                return (
                  <div
                    key={`${rIdx}-${cIdx}`}
                    className={`relative rounded-xl flex items-center justify-center transition-all ${
                      isWall
                        ? 'bg-slate-900 border-2 border-slate-800 shadow-inner'
                        : 'bg-slate-700/60 hover:bg-slate-700/80 border border-slate-600/40'
                    }`}
                  >
                    {/* Maze Wall texture */}
                    {isWall && (
                      <div className="w-2 h-2 rounded-xs bg-slate-800 opacity-60" />
                    )}

                    {/* Suku Kata 1 Crystal */}
                    {isSuku1 && (
                      <div className="animate-bounce flex flex-col items-center">
                        <span className="px-1.5 py-0.5 rounded-md bg-blue-500 text-white font-black text-xs shadow-md">
                          {targetWord.suku1}
                        </span>
                      </div>
                    )}

                    {/* Suku Kata 2 Crystal */}
                    {isSuku2 && (
                      <div className="animate-bounce flex flex-col items-center">
                        <span className="px-1.5 py-0.5 rounded-md bg-rose-500 text-white font-black text-xs shadow-md">
                          {targetWord.suku2}
                        </span>
                      </div>
                    )}

                    {/* Exit Star Gate */}
                    {isGoal && (
                      <div className={`text-xl ${suku1Collected && suku2Collected ? 'animate-spin text-amber-300' : 'opacity-40 text-slate-400'}`}>
                        ⭐
                      </div>
                    )}

                    {/* Player Character */}
                    {isPlayer && (
                      <div className="relative text-2xl md:text-3xl filter drop-shadow-lg animate-mario-hop">
                        <span>🧒</span>
                      </div>
                    )}
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Touch & Virtual D-Pad Controls */}
        <div className="flex flex-col items-center justify-center gap-3">
          <div className="text-xs font-bold text-slate-500 uppercase tracking-wider">
            Kawalan Sentuh / Skrin:
          </div>

          <div className="relative w-44 h-44 bg-slate-100 rounded-3xl p-3 border-2 border-slate-200 shadow-inner flex flex-col items-center justify-between">
            {/* UP */}
            <button
              onClick={() => movePlayer(0, -1)}
              className="w-12 h-12 rounded-2xl bg-white border-2 border-slate-300 shadow-md text-slate-700 hover:bg-indigo-50 hover:border-indigo-400 active:scale-90 flex items-center justify-center transition cursor-pointer"
              title="Atas"
            >
              <ArrowUp className="w-6 h-6" />
            </button>

            {/* LEFT / CENTER / RIGHT */}
            <div className="w-full flex items-center justify-between px-1">
              <button
                onClick={() => movePlayer(-1, 0)}
                className="w-12 h-12 rounded-2xl bg-white border-2 border-slate-300 shadow-md text-slate-700 hover:bg-indigo-50 hover:border-indigo-400 active:scale-90 flex items-center justify-center transition cursor-pointer"
                title="Kiri"
              >
                <ArrowLeft className="w-6 h-6" />
              </button>

              <div className="w-8 h-8 rounded-full bg-slate-300/60" />

              <button
                onClick={() => movePlayer(1, 0)}
                className="w-12 h-12 rounded-2xl bg-white border-2 border-slate-300 shadow-md text-slate-700 hover:bg-indigo-50 hover:border-indigo-400 active:scale-90 flex items-center justify-center transition cursor-pointer"
                title="Kanan"
              >
                <ArrowRight className="w-6 h-6" />
              </button>
            </div>

            {/* DOWN */}
            <button
              onClick={() => movePlayer(0, 1)}
              className="w-12 h-12 rounded-2xl bg-white border-2 border-slate-300 shadow-md text-slate-700 hover:bg-indigo-50 hover:border-indigo-400 active:scale-90 flex items-center justify-center transition cursor-pointer"
              title="Bawah"
            >
              <ArrowDown className="w-6 h-6" />
            </button>
          </div>

          <div className="text-center text-xs text-slate-400">
            Boleh juga gunakan papan kekunci (Arrow Keys atau W/A/S/D)
          </div>
        </div>
      </div>

      {/* Completion Modal Overlay */}
      {isCompleted && (
        <div className="mt-6 p-6 rounded-3xl bg-gradient-to-r from-emerald-500 via-teal-600 to-indigo-600 text-white text-center shadow-xl animate-fade-in flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-4 text-left">
            <div className="p-3 bg-white/20 rounded-2xl backdrop-blur-xs">
              <Trophy className="w-10 h-10 text-amber-300" />
            </div>
            <div>
              <div className="text-xl md:text-2xl font-black">
                Syabas, Murid Hebat! 🎉
              </div>
              <p className="text-emerald-100 text-xs md:text-sm">
                Awak berjaya mengeja <span className="font-extrabold text-white uppercase">{targetWord.word}</span> dalam masa {timerSeconds} saat dan mengumpul 1 bintang emas!
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => initLevel(wordIndex)}
              className="px-4 py-2.5 rounded-xl bg-white/20 hover:bg-white/30 text-white font-bold text-xs backdrop-blur-xs transition cursor-pointer"
            >
              Main Semula
            </button>
            <button
              onClick={nextMaze}
              className="px-5 py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-amber-950 font-black text-sm shadow-md transition active:scale-95 cursor-pointer"
            >
              Maze Seterusnya ➔
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
