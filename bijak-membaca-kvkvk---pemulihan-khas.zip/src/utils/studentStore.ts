import { StudentProfile, ActivityLog } from '../types';
import { LEMBARAN_WORDS } from '../data/wordsData';

const STORAGE_KEY = 'pemulihan_khas_students';
const ACTIVE_STUDENT_KEY = 'pemulihan_khas_active_id';

const DEFAULT_STUDENTS: StudentProfile[] = [
  {
    id: 's-1',
    nama: 'Muhammad Danial Irfan',
    kelas: '2 Cerdik',
    avatar: '👦',
    tarikhDaftar: '2026-03-01',
    bintangTerkumpul: 18,
    syilingMario: 42,
    perkataanDikuasai: ['kicap', 'kotak', 'ketam', 'lalat', 'lebah', 'lemon', 'lobak'],
    perkataanBimbingan: ['kurus', 'lapan', 'lipas', 'lipan'],
    tahapPenguasaan: 2,
    rekodAktiviti: [
      {
        id: 'log-1',
        tarikh: '2026-10-12 09:30',
        aktiviti: 'Pointer Perkataan',
        perkataan: 'kicap',
        markah: 100,
        betul: true,
        masaSaat: 15,
      },
      {
        id: 'log-2',
        tarikh: '2026-10-12 09:35',
        aktiviti: 'Pick and Match',
        perkataan: 'kotak',
        markah: 100,
        betul: true,
        masaSaat: 22,
      },
      {
        id: 'log-3',
        tarikh: '2026-10-13 10:15',
        aktiviti: 'Super Mario',
        perkataan: 'ketam',
        markah: 100,
        betul: true,
        masaSaat: 30,
      },
    ],
  },
  {
    id: 's-2',
    nama: 'Nur Aisyah Humaira',
    kelas: '2 Mawar',
    avatar: '👧',
    tarikhDaftar: '2026-03-01',
    bintangTerkumpul: 28,
    syilingMario: 75,
    perkataanDikuasai: ['kicap', 'kotak', 'kurus', 'ketam', 'lalat', 'lapan', 'lebah', 'lemon', 'lilin', 'lobak', 'makan'],
    perkataanBimbingan: ['lipas', 'lipan', 'lidah', 'mawar'],
    tahapPenguasaan: 3,
    rekodAktiviti: [],
  },
  {
    id: 's-3',
    nama: 'Adam Harith',
    kelas: '3 Bijak',
    avatar: '🧒',
    tarikhDaftar: '2026-03-05',
    bintangTerkumpul: 12,
    syilingMario: 25,
    perkataanDikuasai: ['kicap', 'kotak', 'lalat', 'lobak'],
    perkataanBimbingan: ['kurus', 'ketam', 'lapan', 'lebah'],
    tahapPenguasaan: 2,
    rekodAktiviti: [],
  },
];

export function loadStudents(): StudentProfile[] {
  if (typeof window === 'undefined') return DEFAULT_STUDENTS;
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(DEFAULT_STUDENTS));
      return DEFAULT_STUDENTS;
    }
    return JSON.parse(raw);
  } catch {
    return DEFAULT_STUDENTS;
  }
}

export function saveStudents(students: StudentProfile[]) {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(students));
  } catch {
    // Ignore storage errors
  }
}

export function getActiveStudentId(): string {
  if (typeof window === 'undefined') return 's-1';
  return localStorage.getItem(ACTIVE_STUDENT_KEY) || 's-1';
}

export function setActiveStudentId(id: string) {
  if (typeof window === 'undefined') return;
  localStorage.setItem(ACTIVE_STUDENT_KEY, id);
}

export function kiraTahapPenguasaan(dikuasaiCount: number): number {
  if (dikuasaiCount >= 16) return 6;
  if (dikuasaiCount >= 14) return 5;
  if (dikuasaiCount >= 11) return 4;
  if (dikuasaiCount >= 7) return 3;
  if (dikuasaiCount >= 3) return 2;
  return 1;
}

export function rekodKemajuanMurid(
  studentId: string,
  aktiviti: ActivityLog['aktiviti'],
  perkataan: string,
  betul: boolean,
  markah: number,
  masaSaat: number = 20
): StudentProfile {
  const students = loadStudents();
  const idx = students.findIndex((s) => s.id === studentId);
  const student = idx !== -1 ? students[idx] : students[0];

  const now = new Date();
  const tarikhStr = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')} ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;

  const newLog: ActivityLog = {
    id: `log-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
    tarikh: tarikhStr,
    aktiviti,
    perkataan,
    markah,
    betul,
    masaSaat,
  };

  const updatedLogs = [newLog, ...(student.rekodAktiviti || [])].slice(0, 50);

  let updatedDikuasai = [...student.perkataanDikuasai];
  let updatedBimbingan = [...student.perkataanBimbingan];

  if (betul) {
    if (!updatedDikuasai.includes(perkataan)) {
      updatedDikuasai.push(perkataan);
    }
    updatedBimbingan = updatedBimbingan.filter((w) => w !== perkataan);
  } else {
    if (!updatedBimbingan.includes(perkataan) && !updatedDikuasai.includes(perkataan)) {
      updatedBimbingan.push(perkataan);
    }
  }

  const bintangBaru = betul ? student.bintangTerkumpul + 1 : student.bintangTerkumpul;
  const syilingBaru = aktiviti === 'Super Mario' && betul ? student.syilingMario + 5 : student.syilingMario + (betul ? 2 : 0);
  const tahapBaru = kiraTahapPenguasaan(updatedDikuasai.length);

  const updatedStudent: StudentProfile = {
    ...student,
    bintangTerkumpul: bintangBaru,
    syilingMario: syilingBaru,
    perkataanDikuasai: updatedDikuasai,
    perkataanBimbingan: updatedBimbingan,
    tahapPenguasaan: tahapBaru,
    rekodAktiviti: updatedLogs,
  };

  students[idx !== -1 ? idx : 0] = updatedStudent;
  saveStudents(students);
  return updatedStudent;
}

export const TAHAP_DESKRIPSI: Record<number, { tajuk: string; huraian: string }> = {
  1: {
    tajuk: 'TP1 - Sangat Terhad',
    huraian: 'Murid tahu membunyikan beberapa huruf asas tetapi memerlukan bimbingan penuh untuk mengeja suku kata.',
  },
  2: {
    tajuk: 'TP2 - Terhad',
    huraian: 'Murid boleh mengeja suku kata KVKVK dengan bimbingan berterusan daripada guru.',
  },
  3: {
    tajuk: 'TP3 - Memuaskan',
    huraian: 'Murid berupaya membaca dan mengeja sebahagian besar perkataan KVKVK asas secara berperingkat.',
  },
  4: {
    tajuk: 'TP4 - Baik',
    huraian: 'Murid menguasai kemahiran membaca dan mengeja sebahagian besar perkataan KVKVK dengan lancar dan tepat.',
  },
  5: {
    tajuk: 'TP5 - Sangat Baik',
    huraian: 'Murid menguasai hampir keseluruhan 16 perkataan KVKVK lembaran dan berdikari dalam pelbagai aktiviti gamifikasi.',
  },
  6: {
    tajuk: 'TP6 - Cemerlang',
    huraian: 'Murid menguasai sepenuhnya kesemua 16 perkataan KVKVK dengan tepat, pantas, dan boleh membimbing rakan sebaya.',
  },
};
